import {recipeCost,id} from './domain.mjs';
export const collections=['items','suppliers','customers','sectors','recipes','lots','purchases','productions','trials','sales','expenses','transfers','adjustments'];
const fail=m=>{throw Error(m)};
const refs={itemId:'items',customerId:'customers',supplierId:'suppliers',sectorId:'sectors',lotId:'lots'};
function validate(s){
 if(typeof s.company!=='string'||!s.company.trim())fail('Ingresá el nombre de la empresa.');
 for(const c of collections){if(!Array.isArray(s[c]||[]))fail('Datos inválidos: '+c);const keys=new Set();for(const r of s[c]||[]){if(!r.id||keys.has(r.id))fail('Identificador duplicado o vacío.');keys.add(r.id);}}
 function walk(value,key='',parent={}){
  if(value===null||value===undefined){if(['qty','remaining','unitCost','amount','salePrice','wholesalePrice','yield'].includes(key))fail('Completá las cantidades y los importes.');return;}
  if(typeof value==='number'&&!Number.isFinite(value))fail('Número inválido.');
  if(['qty','remaining','unitCost','amount','salePrice','wholesalePrice','expectedQty','batches','actualQty'].includes(key)&&(typeof value!=='number'||value<0))fail('Las cantidades y los importes deben ser números mayores o iguales a cero.');
  if(key==='yield'&&(typeof value!=='number'||value<=0))fail('El rendimiento debe ser mayor a cero.');
  if(refs[key]&&value&&!s[refs[key]].some(r=>r.id===value))fail('La referencia seleccionada no existe: '+key);
  if(['date','expiry','manufactured','lastStockDate'].includes(key)&&value&&(!/^\d{4}-\d{2}-\d{2}$/.test(value)||new Date(value).toISOString().slice(0,10)!==value))fail('Fecha inválida.');
  if(key==='shelfLifeDays'&&value!==''&&(!Number.isInteger(value)||value<0||value>730))fail('La vida útil debe ser de 0 a 730 días.');
  if(Array.isArray(value))value.forEach(x=>walk(x,'',value));
  else if(typeof value==='object'){
   if(value.lotId&&value.itemId&&s.lots.find(l=>l.id===value.lotId)?.itemId!==value.itemId)fail('El artículo no coincide con el lote seleccionado.');
   for(const [k,v] of Object.entries(value)){if(['__proto__','constructor','prototype'].includes(k))fail('Campo inválido.');walk(v,k,value);}
  }
 }
 walk(s);
 for(const i of s.items){if(!i.name?.trim()||!['raw','packaging','product','subproduct'].includes(i.kind)||!['kg','g','ml','l','u','m'].includes(i.unit))fail('Revisá nombre, tipo y unidad del artículo.');for(const sid of i.supplierIds||[])if(!s.suppliers.some(x=>x.id===sid))fail('Proveedor habitual inexistente.');}
 const outputs=new Set();for(const r of s.recipes){if(!['product','subproduct'].includes(s.items.find(i=>i.id===r.itemId)?.kind)||!s.sectors.some(x=>x.id===r.sectorId))fail('Seleccioná un producto o subproducto y un sector para la receta.');if(outputs.has(r.itemId))fail('Hay dos recetas para el mismo producto.');outputs.add(r.itemId);if(!r.components?.length)fail('La receta necesita componentes.');const used=new Set();for(const c of r.components){if(!s.items.some(i=>i.id===c.itemId)||c.qty<=0||used.has(c.itemId)||c.itemId===r.itemId)fail('Revisá los componentes de la receta.');used.add(c.itemId);}recipeCost(s,r.itemId);}
 for(const l of s.lots){if(!['LIBERADO','BLOQUEADO','RECHAZADO'].includes(l.status)||!l.code?.trim())fail('Revisá código y estado del lote.');if(l.expiry&&l.date&&l.expiry<l.date)fail('El vencimiento no puede ser anterior al ingreso o elaboración.');}
}
// Merge form edits into the full stored record, preserving PDFs and unknown fields.
function merge(before,after){
 if(before&&typeof before==='object'&&!Array.isArray(before)&&after&&typeof after==='object'&&!Array.isArray(after)){const result={...before};for(const [k,v] of Object.entries(after)){if(['__proto__','constructor','prototype'].includes(k))fail('Campo inválido.');if(k==='id'&&before.id&&v!==before.id)fail('No se puede cambiar el identificador interno.');if(k==='data'&&before.data?.startsWith?.('data:application/pdf;'))continue;result[k]=merge(before[k],v);}return result;}
 if(Array.isArray(after))return after.map((v,n)=>merge(Array.isArray(before)?(v?.id?before.find(b=>b?.id===v.id):before[n]):undefined,v));
 return after;
}
export function correct(s,p){
 if(!p.record||typeof p.record!=='object'||Array.isArray(p.record))fail('Datos de corrección inválidos.');
 const c=p.collection;if(!collections.includes(c)&&c!=='configuration')fail('Sección inválida.');
 let before,after;
 if(c==='configuration'){before=Object.fromEntries(Object.entries(s).filter(([,v])=>!Array.isArray(v)));after=merge(before,p.record);for(const k of Object.keys(before))s[k]=after[k];}
 else{const index=(s[c]||[]).findIndex(r=>String(r.id)===String(p.recordId));if(index<0)fail('Registro no encontrado.');before=structuredClone(s[c][index]);after=merge(before,p.record);s[c][index]=after;
  // Correct the linked stock and source record together when an origin quantity changes.
  if(['purchases','productions'].includes(c)){const l=s.lots.find(l=>l.id===after.lotId);if(l){const delta=after.qty-before.qty;l.qty=after.qty;l.remaining+=delta;if(l.remaining<0)fail('La cantidad corregida es menor que lo ya consumido o vendido.');for(const key of ['date','unitCost','itemId','sectorId'])if(after[key]!==undefined)l[key]=after[key];}}
  if(c==='lots'){const source=[...s.purchases,...s.productions,...s.adjustments].find(r=>r.id===after.sourceId);if(source){for(const key of ['qty','date','unitCost','itemId','sectorId'])if(after[key]!==undefined)source[key]=after[key];}}
  // Changing historical consumed lots/quantities adjusts their remaining stock by the difference.
  if(['productions','trials','sales'].includes(c)){const totals=arr=>{const out=new Map();for(const a of arr||[])out.set(a.lotId,(out.get(a.lotId)||0)+a.qty);return out},old=totals(before.inputs),next=totals(after.inputs);for(const lid of new Set([...old.keys(),...next.keys()])){const l=s.lots.find(l=>l.id===lid);if(!l)fail('Lote consumido inexistente.');l.remaining+=(old.get(lid)||0)-(next.get(lid)||0);if(l.remaining<0)fail('La corrección consumiría más stock del disponible.');}}
 }
 validate(s);
 if(c==='lots'||['purchases','productions','trials','sales'].includes(c)){s.averages??={};for(const i of s.items){const lots=s.lots.filter(l=>l.itemId===i.id&&l.remaining>0),qty=lots.reduce((n,l)=>n+l.remaining,0);s.averages[i.id]=qty?lots.reduce((n,l)=>n+l.remaining*l.unitCost,0)/qty:0;}}
 return {id:id(),collection:c,recordId:p.recordId||'',before,after:structuredClone(after)};
}
