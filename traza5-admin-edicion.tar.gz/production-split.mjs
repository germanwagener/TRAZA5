const scopes=new Set(['both','primary','secondary']);
export const outputScope=value=>scopes.has(value)?value:'both';
const positive=(value,label)=>{const number=Number(value);if(!Number.isFinite(number)||number<=0)throw Error(label+' debe ser mayor que cero.');return number};
const rounded=value=>Math.round((Number(value)+Number.EPSILON)*1e6)/1e6;

export function productionOutputs(recipe,data){
 if(!recipe.secondaryItemId)return[{role:'single',itemId:recipe.itemId,qty:positive(data.qty,'La cantidad producida'),suffix:''}];
 const primary=data.primaryQty===undefined||data.primaryQty===''?Number(recipe.yield):positive(data.primaryQty,'La cantidad del primer producto'),secondary=positive(data.secondaryQty,'La cantidad del segundo producto');
 return[{role:'primary',itemId:recipe.itemId,qty:primary,suffix:'-1'},{role:'secondary',itemId:recipe.secondaryItemId,qty:secondary,suffix:'-2'}];
}

export function splitRequirements(recipe,batches,primaryQty=0,secondaryQty=0){
 const count=positive(batches,'La cantidad de recetas');
 if(!recipe.secondaryItemId)return recipe.components.map(component=>({...component,scope:'both',required:rounded(Number(component.qty)*count)}));
 const primary=primaryQty===undefined||primaryQty===''?Number(recipe.yield)*count:positive(primaryQty,'La cantidad del primer producto'),secondary=positive(secondaryQty,'La cantidad del segundo producto'),total=primary+secondary;
 return recipe.components.map(component=>{const scope=outputScope(component.scope),share=scope==='primary'?primary/total:scope==='secondary'?secondary/total:1;return{...component,scope,required:rounded(Number(component.qty)*count*share)}});
}

export function allocateProductionInputs(inputs,recipe,outputs){
 if(outputs.length===1)return[inputs.map(input=>({...input}))];
 const total=outputs[0].qty+outputs[1].qty,result=[[],[]],byItem=new Map(recipe.components.map(component=>[component.itemId,outputScope(component.scope)]));
 for(const input of inputs){const scope=byItem.get(input.itemId)||'both';if(scope==='primary'){result[0].push({...input});continue}if(scope==='secondary'){result[1].push({...input});continue}
  const first=rounded(Number(input.qty)*outputs[0].qty/total),second=rounded(Number(input.qty)-first);if(first>0)result[0].push({...input,qty:first});if(second>0)result[1].push({...input,qty:second});
 }
 return result;
}
