const definitions=new Map([
 ['kg',{key:'kg',dimension:'mass',factor:1}],['kilo',{key:'kg',dimension:'mass',factor:1}],['kilos',{key:'kg',dimension:'mass',factor:1}],['kilogramo',{key:'kg',dimension:'mass',factor:1}],['kilogramos',{key:'kg',dimension:'mass',factor:1}],
 ['g',{key:'g',dimension:'mass',factor:.001}],['gr',{key:'g',dimension:'mass',factor:.001}],['gramo',{key:'g',dimension:'mass',factor:.001}],['gramos',{key:'g',dimension:'mass',factor:.001}],
 ['l',{key:'l',dimension:'volume',factor:1}],['lt',{key:'l',dimension:'volume',factor:1}],['litro',{key:'l',dimension:'volume',factor:1}],['litros',{key:'l',dimension:'volume',factor:1}],
 ['ml',{key:'ml',dimension:'volume',factor:.001}],['mililitro',{key:'ml',dimension:'volume',factor:.001}],['mililitros',{key:'ml',dimension:'volume',factor:.001}],
 ['u',{key:'u',dimension:'count',factor:1}],['unidad',{key:'u',dimension:'count',factor:1}],['unidades',{key:'u',dimension:'count',factor:1}],
 ['m',{key:'m',dimension:'length',factor:1}],['metro',{key:'m',dimension:'length',factor:1}],['metros',{key:'m',dimension:'length',factor:1}],
 ['feta',{key:'feta',dimension:'slice',factor:1}],['fetas',{key:'feta',dimension:'slice',factor:1}]
]);

export const normalizeUnit=value=>String(value||'').trim().toLocaleLowerCase().replaceAll('.','');
export function unitDefinition(value){const normalized=normalizeUnit(value);return definitions.get(normalized)||{key:normalized,dimension:'custom:'+normalized,factor:1}}
export function compatibleUnits(value){const target=unitDefinition(value);return [...new Map([...definitions.values()].filter(x=>x.dimension===target.dimension).map(x=>[x.key,x])).values()].map(x=>x.key)}
export function baseQuantity(presentationQty,contentPerPresentation,contentUnit,stockUnit){
 const count=Number(presentationQty),content=Number(contentPerPresentation),source=unitDefinition(contentUnit),target=unitDefinition(stockUnit);
 if(!Number.isFinite(count)||count<=0||!Number.isFinite(content)||content<=0)throw Error('La cantidad y el contenido por presentación deben ser mayores que cero.');
 if(!source.key||!target.key||source.dimension!==target.dimension)throw Error('La unidad '+contentUnit+' no se puede convertir a '+stockUnit+'.');
 const result=count*content*source.factor/target.factor,rounded=Math.round((result+Number.EPSILON)*1e6)/1e6;
 if(!Number.isFinite(rounded)||rounded<=0)throw Error('La cantidad total calculada no es válida.');return rounded;
}
