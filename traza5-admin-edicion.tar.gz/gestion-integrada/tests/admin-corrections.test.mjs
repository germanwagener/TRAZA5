import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn,spawnSync} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {empty,operate} from '../domain.mjs';
import {correct} from '../admin-corrections.mjs';
function fixture(){const s=empty('Prueba'),sector=operate(s,'master',{collection:'sectors',name:'Elaboración'}),raw=operate(s,'master',{collection:'items',name:'Harina',kind:'raw',unit:'kg'}),out=operate(s,'master',{collection:'items',name:'Pizza',kind:'product',unit:'u'}),supplier=operate(s,'master',{collection:'suppliers',name:'Molino'});const purchase=operate(s,'purchase',{itemId:raw.id,supplierId:supplier.id,sectorId:sector.id,date:'2026-10-07',expiry:'2027-01-01',supplierLot:'L1',qty:10,unitCost:5});const recipe=operate(s,'recipe',{itemId:out.id,sectorId:sector.id,yield:10,components:[{itemId:raw.id,qty:5}]});return{s,sector,raw,out,recipe,purchase};}
test('Corrección preserva PDF y receta histórica; sincroniza cantidades de ingreso y lote',()=>{const f=fixture(),{s,recipe,purchase}=f;f.raw.documents=[{id:'pdf',name:'original.pdf',data:'data:application/pdf;base64,secret'}];correct(s,{collection:'items',recordId:f.raw.id,record:{...f.raw,name:'Harina corregida',documents:[{id:'pdf',name:'nuevo.pdf'}]}});assert.equal(f.raw.documents[0].data,'data:application/pdf;base64,secret');assert.equal(s.items[0].documents[0].data,'data:application/pdf;base64,secret');correct(s,{collection:'recipes',recordId:recipe.id,record:{...recipe,yield:20}});assert.equal(s.recipes[0].yield,20);correct(s,{collection:'purchases',recordId:purchase.id,record:{...purchase,qty:12}});assert.equal(s.lots[0].qty,12);assert.equal(s.lots[0].remaining,12);assert.throws(()=>correct(structuredClone(s),{collection:'lots',recordId:s.lots[0].id,record:{...s.lots[0],remaining:-1}}),/mayores o iguales/);assert.throws(()=>correct(structuredClone(s),{collection:'recipes',recordId:recipe.id,record:{...recipe,components:[{itemId:f.out.id,qty:1}]}}),/componentes/);});
test('Administrador corrige con versión, aislamiento y auditoría; eliminar y recuperar conserva datos y cierra sesiones',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'traza-admin-')),dbPath=join(dir,'db.sqlite'),port=31849,origin=`http://localhost:${port}`,env={...process.env,DB_PATH:dbPath,PORT:String(port),PUBLIC_ORIGIN:origin,ADMIN_USER:'admin',ADMIN_PASSWORD:'LocalTestAdmin-1234'};
 assert.equal(spawnSync(process.execPath,['server.mjs','--create-admin'],{cwd:new URL('..',import.meta.url),env}).status,0);
 const child=spawn(process.execPath,['server.mjs'],{cwd:new URL('..',import.meta.url),env,stdio:['ignore','pipe','pipe']});await new Promise((r,j)=>{child.stdout.once('data',r);child.once('error',j)});
 async function req(path,data,cookie=''){const r=await fetch(origin+'/api/'+path,{method:data?'POST':'GET',headers:{Cookie:cookie,...(data?{Origin:origin,'Content-Type':'application/json'}:{})},body:data?JSON.stringify(data):undefined});return{status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};}
 try{
 const ac=(await req('login',{username:'admin',password:env.ADMIN_PASSWORD})).cookie;
 await req('admin',{op:'create',username:'empresa',password:'LocalCompany-1234',companyName:'Prueba'},ac);
 let list=(await req('admin',null,ac)).data,c=list.companies[0],u=list.users.find(x=>x.role==='company');
 const db=new DatabaseSync(dbPath),f=fixture();db.prepare('UPDATE companies SET state=? WHERE id=?').run(JSON.stringify(f.s),c.id);db.close();
 assert.equal((await req('state',null,ac)).status,403);let loaded=await req('state?companyId='+c.id,null,ac);assert.equal(loaded.data.state.recipes.length,1);
 const company=await req('login',{username:'empresa',password:'LocalCompany-1234'});await req('password',{oldPassword:'LocalCompany-1234',newPassword:'LocalCompanyNew-1234'},company.cookie);const cc=(await req('login',{username:'empresa',password:'LocalCompanyNew-1234'})).cookie;
 const change={collection:'recipes',recordId:f.recipe.id,record:{...f.recipe,yield:25},reason:'Corrección de rendimiento',version:0};
 assert.equal((await req('admin/correct?companyId='+c.id,change,cc)).status,403);
 assert.equal((await req('admin/correct?companyId='+c.id,change,ac)).status,200);
 assert.equal((await req('admin/correct?companyId='+c.id,change,ac)).status,409);
 assert.equal((await req('state?companyId='+c.id,null,cc)).data.state.recipes[0].yield,25);
 assert.equal((await req('audit?companyId='+c.id,null,ac)).data.rows[0].operation,'admin_correction');
 assert.equal((await req('admin',{op:'deleteCompany',userId:u.id,confirmation:'incorrecto'},ac)).status,400);
 assert.equal((await req('admin',{op:'deleteCompany',userId:u.id,confirmation:'Prueba'},ac)).status,200);
 assert.equal((await req('me',null,cc)).status,401);list=(await req('admin',null,ac)).data;assert.equal(list.companies.length,0);assert.equal(list.deletedCompanies.length,1);
 assert.equal((await req('admin',{op:'restoreCompany',companyId:c.id},ac)).status,200);
 loaded=await req('state?companyId='+c.id,null,ac);assert.equal(loaded.data.state.recipes[0].yield,25);assert.ok(loaded.data.version>1);assert.equal((await req('admin',null,ac)).data.deletedCompanies.length,0);
 }finally{child.kill();await new Promise(r=>child.once('exit',r));rmSync(dir,{recursive:true,force:true})}
});
