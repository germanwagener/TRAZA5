import test from 'node:test';
import assert from 'node:assert/strict';
import {allocateProductionInputs,productionOutputs,splitRequirements} from '../production-split.mjs';

const recipe={itemId:'salsa',secondaryItemId:'cebolla',components:[{itemId:'masa',qty:26,scope:'both'},{itemId:'tomate',qty:4,scope:'primary'},{itemId:'cebolla-cruda',qty:3,scope:'secondary'}]};

test('producción dividida crea dos salidas y conserva el total común',()=>{
 const outputs=productionOutputs(recipe,{primaryQty:916,secondaryQty:15});
 const [a,b]=allocateProductionInputs([{lotId:'masa-1',itemId:'masa',qty:26,unitCost:2},{lotId:'tomate-1',itemId:'tomate',qty:4,unitCost:1},{lotId:'cebolla-1',itemId:'cebolla-cruda',qty:3,unitCost:1}],recipe,outputs);
 assert.equal(a.find(x=>x.itemId==='masa').qty,25.581096);assert.equal(b.find(x=>x.itemId==='masa').qty,.418904);
 assert.equal(a.find(x=>x.itemId==='masa').qty+b.find(x=>x.itemId==='masa').qty,26);
 assert.ok(a.some(x=>x.itemId==='tomate'));assert.ok(!b.some(x=>x.itemId==='tomate'));
 assert.ok(b.some(x=>x.itemId==='cebolla-cruda'));assert.ok(!a.some(x=>x.itemId==='cebolla-cruda'));
});

test('ingredientes exclusivos se escalan según las dos cantidades producidas',()=>{
 const rows=splitRequirements(recipe,1,90,10);assert.equal(rows.find(x=>x.itemId==='masa').required,26);assert.equal(rows.find(x=>x.itemId==='tomate').required,3.6);assert.equal(rows.find(x=>x.itemId==='cebolla-cruda').required,.3);
});
