import test from 'node:test';
import assert from 'node:assert/strict';
import {baseQuantity,compatibleUnits} from '../units.mjs';

test('presentaciones convierten bidones, bolsas y fetas a la unidad de stock',()=>{
 assert.equal(baseQuantity(6,5,'l','l'),30);
 assert.equal(baseQuantity(2,2500,'g','kg'),5);
 assert.equal(baseQuantity(4,25,'feta','feta'),100);
 assert.deepEqual(compatibleUnits('kg'),['kg','g']);
});

test('presentaciones rechazan unidades incompatibles',()=>assert.throws(()=>baseQuantity(2,5,'l','kg'),/no se puede convertir/));
