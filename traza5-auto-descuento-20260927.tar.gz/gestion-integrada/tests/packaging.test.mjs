import {test} from 'node:test';
import assert from 'node:assert/strict';
import {empty,operate} from '../domain.mjs';

test('Envases por unidad o metro ingresan como mercadería y se descuentan en recetas',()=>{
 const s=empty('Envases'),sector=operate(s,'master',{collection:'sectors',name:'Depósito'}),supplier=operate(s,'master',{collection:'suppliers',name:'Proveedor'});
 const film=operate(s,'master',{collection:'items',name:'Film alimentario',kind:'packaging',unit:'m',supplierIds:[supplier.id]});
 const tray=operate(s,'master',{collection:'items',name:'Bandeja',kind:'packaging',unit:'u',supplierIds:[supplier.id]});
 const flour=operate(s,'master',{collection:'items',name:'Harina',kind:'raw',unit:'kg',supplierIds:[supplier.id]});
 const filmPurchase=operate(s,'purchase',{date:'2026-10-01',itemId:film.id,supplierId:supplier.id,supplierLot:'FILM-1',qty:100,unitCost:4,sectorId:sector.id,expiry:'2027-12-31'});
 const trayPurchase=operate(s,'purchase',{date:'2026-10-01',itemId:tray.id,supplierId:supplier.id,supplierLot:'BAN-1',qty:50,unitCost:2,sectorId:sector.id,expiry:'2027-12-31'});
 const flourPurchase=operate(s,'purchase',{date:'2026-10-01',itemId:flour.id,supplierId:supplier.id,supplierLot:'HAR-1',qty:10,unitCost:1,sectorId:sector.id,expiry:'2027-12-31'});
 const recipe=operate(s,'recipe',{name:'Producto envasado',kind:'product',unit:'u',sectorId:sector.id,yield:10,components:[{itemId:flour.id,qty:1},{itemId:film.id,qty:3},{itemId:tray.id,qty:10}]});
 operate(s,'produce',{date:'2026-10-02',recipeId:recipe.id,batches:1,qty:10,expiry:'2026-12-31',allocations:[{lotId:flourPurchase.lotId,qty:1},{lotId:filmPurchase.lotId,qty:3},{lotId:trayPurchase.lotId,qty:10}]});
 assert.equal(s.lots.find(l=>l.id===filmPurchase.lotId).remaining,97);assert.equal(s.lots.find(l=>l.id===trayPurchase.lotId).remaining,40);
});
