import {randomBytes,createHash} from 'node:crypto';
import {readFileSync,writeFileSync,existsSync,renameSync} from 'node:fs';
import {join} from 'node:path';
import {seal,unseal,backupDay} from './backups.mjs';

export function driveBackups({directory,store,origin,env=process.env,fetcher=fetch}){
 const key=readFileSync(join(directory,'recovery.key')),file=join(directory,'drive.config.enc');
 let config=existsSync(file)?unseal(readFileSync(file),key):{},busy=false,lastError=null;
 const pending=new Map();
 const save=()=>{writeFileSync(file+'.tmp',seal(config,key),{mode:0o600});renameSync(file+'.tmp',file)};
 const credentials=()=>({id:env.GOOGLE_CLIENT_ID,secret:env.GOOGLE_CLIENT_SECRET});
 const callback=origin+'/api/admin/drive/callback';
 async function request(url,options={}){
  const r=await fetcher(url,{...options,signal:AbortSignal.timeout(60000)});
  if(!r.ok)throw Error('Google Drive no pudo completar la operación (HTTP '+r.status+'). Revisá la conexión y el espacio disponible.');
  return r;
 }
 async function token(params){const c=credentials();return(await request('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:c.id,client_secret:c.secret,...params})})).json()}
 async function access(){if(!config.refreshToken)throw Error('Primero conectá Google Drive.');return(await token({grant_type:'refresh_token',refresh_token:config.refreshToken})).access_token}
 async function api(path,options={}){const t=await access();return request('https://www.googleapis.com/drive/v3/'+path,{...options,headers:{Authorization:'Bearer '+t,...options.headers}})}
 function start(userId){
  const c=credentials();if(!c.id||!c.secret)throw Error('Falta configurar la credencial de Google en Railway.');
  for(const [s,p] of pending)if(p.expires<Date.now())pending.delete(s);
  const state=randomBytes(32).toString('hex'),verifier=randomBytes(32).toString('base64url');pending.set(state,{userId,verifier,expires:Date.now()+600000});
  return 'https://accounts.google.com/o/oauth2/v2/auth?'+new URLSearchParams({client_id:c.id,redirect_uri:callback,response_type:'code',scope:'https://www.googleapis.com/auth/drive.file',access_type:'offline',prompt:'consent',state,code_challenge:createHash('sha256').update(verifier).digest('base64url'),code_challenge_method:'S256',login_hint:'consultora.alimentos.ros@gmail.com'});
 }
 async function finish(params,validAdmin){
  const p=pending.get(params.get('state'));pending.delete(params.get('state'));
  if(!p||p.expires<Date.now()||!validAdmin(p.userId))throw Error('La autorización venció. Iniciá nuevamente desde el administrador.');
  if(params.get('error')||!params.get('code'))throw Error('Google no autorizó la conexión.');
  const t=await token({grant_type:'authorization_code',code:params.get('code'),redirect_uri:callback,code_verifier:p.verifier});
  if(!t.refresh_token)throw Error('Google no entregó el permiso para respaldos automáticos.');
  const profile=await(await request('https://www.googleapis.com/drive/v3/about?fields=user(emailAddress)',{headers:{Authorization:'Bearer '+t.access_token}})).json();
  if(profile.user?.emailAddress!=='consultora.alimentos.ros@gmail.com')throw Error('Elegí la cuenta consultora.alimentos.ros@gmail.com.');
  config.refreshToken=t.refresh_token;config.email=profile.user.emailAddress;save();
  if(!config.folder&&env.GOOGLE_DRIVE_FOLDER){await api('files/'+encodeURIComponent(env.GOOGLE_DRIVE_FOLDER)+'?fields=id');config.folder=env.GOOGLE_DRIVE_FOLDER;save()}
  if(!config.folder){const folder=await(await api('files?fields=id',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:'Respaldos Traza',mimeType:'application/vnd.google-apps.folder'})})).json();config.folder=folder.id;save()}
 }
 async function files(){if(!config.folder)return[];let all=[],page='';do{
  const q=new URLSearchParams({q:`'${config.folder}' in parents and trashed = false`,fields:'nextPageToken,files(id,name,md5Checksum,size)',pageSize:'1000',...(page?{pageToken:page}:{})});
  const result=await(await api('files?'+q)).json();all.push(...result.files);page=result.nextPageToken;
 }while(page);return all.filter(f=>/^Traza_\d{4}-\d{2}-\d{2}_[a-z0-9-]+\.respaldo\.enc$/.test(f.name))}
 async function upload(name){
  const bytes=store.bytes(name),checksum=createHash('md5').update(bytes).digest('hex');
  if((await files()).some(f=>f.name===name&&f.md5Checksum===checksum))return;
  const t=await access(),r=await request('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,md5Checksum',{method:'POST',headers:{Authorization:'Bearer '+t,'Content-Type':'application/json','X-Upload-Content-Type':'application/octet-stream'},body:JSON.stringify({name,parents:[config.folder]})});
  const location=r.headers.get('location');if(!location||new URL(location).origin!=='https://www.googleapis.com')throw Error('Respuesta de subida inválida.');
  const result=await(await request(location,{method:'PUT',headers:{'Content-Type':'application/octet-stream'},body:bytes})).json();
  if(result.md5Checksum!==checksum)throw Error('No se pudo verificar la copia en Drive.');
 }
 async function sync(){
  if(busy||!config.folder||!config.refreshToken)return;busy=true;
  try{
   const day=backupDay();let daily=store.list().find(b=>b.date===day&&b.name.includes('_diario-'));
   if(!daily)daily=store.create('diario');
   const remote=await files();for(const b of store.list())if(!remote.some(f=>f.name===b.name&&f.md5Checksum===createHash('md5').update(store.bytes(b.name)).digest('hex')))await upload(b.name);
   config.lastSuccess=new Date().toISOString();save();lastError=null;
  }catch(e){lastError=e.message}finally{busy=false}
 }
 async function list(){const local=store.list();if(!config.folder)return local;const remote=await files();return [...new Map([...local.map(b=>[b.name,{...b,drive:false}]),...remote.map(b=>[b.name,{name:b.name,date:b.name.slice(6,16),drive:true}])]).values()].sort((a,b)=>b.name.localeCompare(a.name))}
 async function ensure(name){if(store.list().some(b=>b.name===name))return;const match=(await files()).find(f=>f.name===name);if(!match)throw Error('Respaldo no encontrado.');const bytes=Buffer.from(await(await api('files/'+encodeURIComponent(match.id)+'?alt=media')).arrayBuffer());store.importBytes(name,bytes)}
 return{start,finish,sync,list,ensure,status:()=>({configured:!!credentials().id&&!!credentials().secret,connected:!!config.folder&&!!config.refreshToken,lastSuccess:config.lastSuccess||null,error:lastError,email:config.email||null,folder:config.folder||null})};
}
