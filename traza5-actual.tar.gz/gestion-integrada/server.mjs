import {importTraza5} from './import-traza5.mjs';
import {createBackupStore} from './backups.mjs';
import {driveBackups} from './drive-backups.mjs';
import {suggestLots,forecast} from './planning.mjs';
import http from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {randomBytes,scryptSync,timingSafeEqual,createHash} from 'node:crypto';
import {mkdirSync,readFileSync,existsSync} from 'node:fs';
import {dirname,resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {empty,operate,report,trace,id,avgCost,recipeCost} from './domain.mjs';
const root=dirname(fileURLToPath(import.meta.url));
const dbPath=process.env.DB_PATH||join(root,'data','gestion.sqlite');mkdirSync(dirname(dbPath),{recursive:true});
const db=new DatabaseSync(dbPath);db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
 CREATE TABLE IF NOT EXISTS companies(id TEXT PRIMARY KEY,name TEXT NOT NULL,state TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('admin','company')),company_id TEXT REFERENCES companies(id),blocked INTEGER NOT NULL DEFAULT 0,must_change INTEGER NOT NULL DEFAULT 1);
 CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY,at TEXT NOT NULL,user_id TEXT NOT NULL,company_id TEXT,operation TEXT NOT NULL,detail TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS attempts(key TEXT PRIMARY KEY,count INTEGER NOT NULL,until INTEGER NOT NULL);
 CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id);
 CREATE INDEX IF NOT EXISTS audit_company ON audit(company_id,at);`);
const hashToken=x=>createHash('sha256').update(x).digest('hex');
function password(p){if(typeof p!=='string'||p.length<4||p.length>128)throw Error('La contraseña debe tener entre 4 y 128 caracteres.');const salt=randomBytes(16).toString('hex');return salt+':'+scryptSync(p,salt,64).toString('hex')}
function check(p,encoded){if(typeof p!=='string'||p.length>128)return false;const [salt,h]=encoded.split(':');return timingSafeEqual(scryptSync(p,salt,64),Buffer.from(h,'hex'))}
function log(u,operation,detail){db.prepare('INSERT INTO audit VALUES(?,?,?,?,?,?)').run(id(),new Date().toISOString(),u.id,u.company_id||null,operation,JSON.stringify(detail,(key,value)=>key==='data'&&typeof value==='string'&&value.startsWith('data:application/pdf;')?'[PDF adjunto]':value))}
function tx(fn){db.exec('BEGIN IMMEDIATE');try{const r=fn();db.exec('COMMIT');return r}catch(e){db.exec('ROLLBACK');throw e}}
function publicUser(u){return{id:u.id,username:u.username,role:u.role,companyId:u.company_id,blocked:!!u.blocked,mustChange:!!u.must_change}}
if(process.argv.includes('--has-admin')){console.log(db.prepare("SELECT id FROM users WHERE role='admin'").get()?'yes':'no');process.exit(0)}
if(process.argv.includes('--create-admin')){
 const username=process.env.ADMIN_USER||'administrador';const pass=process.env.ADMIN_PASSWORD;
 if(!pass){console.error('Definí ADMIN_PASSWORD (4 caracteres como mínimo).');process.exit(1)}
 if(db.prepare("SELECT id FROM users WHERE role='admin'").get()){console.error('Ya existe un administrador.');process.exit(1)}
 db.prepare('INSERT INTO users(id,username,password,role,must_change) VALUES(?,?,?,?,0)').run(id(),username,password(pass),'admin');console.log('Administrador creado.');process.exit(0)
}
const PORT=Number(process.env.PORT||3000),HOST=process.env.HOST||'127.0.0.1';let PUBLIC=process.env.PUBLIC_ORIGIN||`http://localhost:${PORT}`;
if(!PUBLIC.startsWith('https://')&&!/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(PUBLIC)){throw Error('PUBLIC_ORIGIN debe usar HTTPS fuera de la computadora local.')}
const secure=PUBLIC.startsWith('https://');const cookie=(t,age)=>`gestion_session=${t}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${age}${secure?'; Secure':''}`;
const backups=createBackupStore(db,join(dirname(dbPath),'backups'));
const drive=driveBackups({directory:join(dirname(dbPath),'backups'),store:backups,origin:PUBLIC});
const backupTimer=setInterval(()=>{void drive.sync()},15*60*1000);backupTimer.unref();
void drive.sync();
function send(res,status,data,headers={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers});res.end(JSON.stringify(data))}
async function body(req){let data='';for await(const chunk of req){data+=chunk;if(data.length>8e6)throw Error('Solicitud demasiado grande.')}return JSON.parse(data||'{}')}
const server=http.createServer(async(req,res)=>{try{
 const url=new URL(req.url,PUBLIC),path=url.pathname;
 if(!['GET','POST'].includes(req.method))return send(res,405,{error:'Método no permitido.'});
 if(req.method==='POST'&&req.headers.origin!==PUBLIC)return send(res,403,{error:'Origen no autorizado.'});
 if(path==='/health'&&req.method==='GET'){db.prepare('SELECT 1').get();return send(res,200,{ok:true});}
 if(path==='/api/admin/drive/callback'&&req.method==='GET'){
  try{await drive.finish(url.searchParams,uid=>!!db.prepare("SELECT id FROM users WHERE id=? AND role='admin' AND blocked=0 AND must_change=0").get(uid));void drive.sync();res.writeHead(303,{Location:'/', 'Cache-Control':'no-store','Referrer-Policy':'no-referrer'});return res.end()}
  catch(e){return send(res,400,{error:e.message})}
 }
 if(!path.startsWith('/api/')){
  if(req.method!=='GET')return send(res,405,{error:'Método no permitido.'});
  const files={'/':'index.html','/privacidad':'privacy.html','/condiciones':'terms.html','/manifest.webmanifest':'manifest.webmanifest','/sw.js':'sw.js','/pdf-lib.min.js':'pdf-lib.min.js','/app.js':'app.js','/styles.css':'styles.css','/assets/logo.png':'assets/logo.png','/assets/traza-icon.svg':'assets/traza-icon.svg'};if(!files[path])return send(res,404,{error:'No encontrado.'});const f=join(root,'public',files[path]);const mime=f.endsWith('.webmanifest')?'application/manifest+json':f.endsWith('.js')?'text/javascript':f.endsWith('.css')?'text/css':f.endsWith('.png')?'image/png':f.endsWith('.svg')?'image/svg+xml':'text/html';res.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"});return res.end(readFileSync(f));
 }
 if(path==='/api/login'&&req.method==='POST'){
  const p=await body(req),username=String(p.username||'').trim().toLowerCase();const key=hashToken(username),attempt=db.prepare('SELECT * FROM attempts WHERE key=?').get(key),now=Date.now();if(attempt&&attempt.until>now&&attempt.count>=8)return send(res,429,{error:'Demasiados intentos. Esperá 15 minutos.'});
  const u=db.prepare('SELECT * FROM users WHERE username=?').get(username);const dummy='f'.repeat(32)+':'+ '0'.repeat(128);const valid=check(p.password,u?.password||dummy);if(!u||!valid||u.blocked){const count=attempt&&attempt.until>now?attempt.count+1:1;db.prepare('INSERT OR REPLACE INTO attempts VALUES(?,?,?)').run(key,count,now+15*60*1000);return send(res,401,{error:'Usuario o contraseña incorrectos, o cuenta bloqueada.'})}
  db.prepare('DELETE FROM attempts WHERE key=?').run(key);db.prepare('DELETE FROM sessions WHERE expires<?').run(now);const t=randomBytes(32).toString('hex');db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hashToken(t),u.id,now+8*3600000);log(u,'login',{});return send(res,200,{user:publicUser(u)},{'Set-Cookie':cookie(t,8*3600)})
 }
 const token=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('gestion_session='))?.slice(16)||'';
 const u=db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>? AND u.blocked=0').get(hashToken(token),Date.now());if(!u)return send(res,401,{error:'Iniciá sesión.'});
 if(path==='/api/me')return send(res,200,{user:publicUser(u)});
 if(path==='/api/logout'&&req.method==='POST'){db.prepare('DELETE FROM sessions WHERE token=?').run(hashToken(token));return send(res,200,{ok:true},{'Set-Cookie':cookie('',0)})}
 if(path==='/api/password'&&req.method==='POST'){
  const p=await body(req);if(!check(p.oldPassword,u.password))return send(res,400,{error:'La contraseña actual no coincide.'});const encoded=password(p.newPassword);tx(()=>{db.prepare('UPDATE users SET password=?,must_change=0 WHERE id=?').run(encoded,u.id);db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);log(u,'password_changed',{})});return send(res,200,{ok:true},{'Set-Cookie':cookie('',0)})
 }
 if(u.must_change)return send(res,403,{error:'Primero cambiá tu contraseña inicial.'});
 if(path==='/api/admin/drive'&&u.role==='admin'&&req.method==='POST'){
  const p=await body(req);if(p.op==='connect')return send(res,200,{url:drive.start(u.id)});
  if(p.op==='sync'){await drive.sync();return send(res,200,drive.status())}
  if(p.op==='recovery'){
   if(!check(p.password,u.password))throw Error('La contraseña del administrador no coincide.');
   return send(res,200,{key:readFileSync(join(dirname(dbPath),'backups','recovery.key')).toString('base64')});
  }
  throw Error('Operación inválida.');
 }
 if(path==='/api/admin/backups'){
  if(u.role!=='admin')return send(res,403,{error:'Solo el administrador puede gestionar respaldos.'});
  if(req.method==='GET'){let list=backups.list(),listingError=null;try{list=await drive.list()}catch(e){listingError=e.message}return send(res,200,{backups:list,drive:drive.status(),listingError});}
  const p=await body(req);
  if(p.op==='create'){const created=backups.create();void drive.sync();return send(res,200,created)}
  if(p.op==='preview'){await drive.ensure(p.name);return send(res,200,backups.preview(p.name))}
  if(p.op==='restore'){
   if(p.confirmation!==`RESTAURAR ${p.name}`)throw Error('Confirmá el respaldo que querés restaurar.');
   await drive.ensure(p.name);
   const result=backups.restore(p.name,u.id);return send(res,200,{ok:true,...result},{'Set-Cookie':cookie('',0)});
  }
  throw Error('Operación inválida.');
 }
 if(path==='/api/admin'&&u.role==='admin'){
  if(req.method==='GET')return send(res,200,{companies:db.prepare('SELECT id,name FROM companies').all(),users:db.prepare('SELECT * FROM users').all().map(publicUser)});
  const p=await body(req);const result=tx(()=>{
   if(p.op==='create'){
    const username=String(p.username||'').trim().toLowerCase();if(!/^[a-z0-9_.-]{3,60}$/.test(username))throw Error('Usuario: 3 a 60 letras sin acentos, números, puntos o guiones.');const encoded=password(p.password);let cid=p.companyId;const imported=p.trazaData?importTraza5(p.trazaData,p.trazaClientId):null;if(imported&&cid)throw Error('La importación crea una empresa nueva.');
    if(!cid){const name=String(imported?.company||p.companyName||'').trim();if(!name)throw Error('Ingresá la empresa.');cid=id();db.prepare('INSERT INTO companies(id,name,state) VALUES(?,?,?)').run(cid,name,JSON.stringify(imported||empty(name)))}else if(!db.prepare('SELECT id FROM companies WHERE id=?').get(cid))throw Error('Empresa inexistente.');
    const userId=id();db.prepare('INSERT INTO users(id,username,password,role,company_id) VALUES(?,?,?,?,?)').run(userId,username,encoded,'company',cid);log(u,'user_created',{userId,companyId:cid});return{ok:true}
   }
   const target=db.prepare('SELECT * FROM users WHERE id=? AND role=?').get(p.userId,'company');if(!target)throw Error('Usuario de empresa no encontrado.');
   if(p.op==='reset'){db.prepare('UPDATE users SET password=?,must_change=1 WHERE id=?').run(password(p.password),target.id)}else if(p.op==='block'){db.prepare('UPDATE users SET blocked=? WHERE id=?').run(p.blocked?1:0,target.id)}else throw Error('Operación inválida.');db.prepare('DELETE FROM sessions WHERE user_id=?').run(target.id);log(u,p.op,{userId:target.id});return{ok:true}
  });return send(res,200,result)
 }
 if(u.role!=='company'||!u.company_id)return send(res,403,{error:'Tu administrador gestiona accesos; no tiene acceso a datos operativos.'});
 const company=()=>db.prepare('SELECT * FROM companies WHERE id=?').get(u.company_id);
 if(path==='/api/document'&&req.method==='GET'){
  const s=JSON.parse(company().state),collection=url.searchParams.get('collection');
  if(!['items','suppliers'].includes(collection))throw Error('Documento inexistente.');
  const row=s[collection].find(x=>x.id===url.searchParams.get('record')),doc=row?.documents?.find(x=>x.id===url.searchParams.get('id'));
  if(!doc)return send(res,404,{error:'Documento inexistente.'});
  res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':(url.searchParams.has('download')?"attachment":"inline")+"; filename*=UTF-8''"+encodeURIComponent(doc.name),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});return res.end(Buffer.from(doc.data.split(',')[1],'base64'));
 }
 if(path==='/api/state'&&req.method==='GET'){const c=company(),s=JSON.parse(c.state);return send(res,200,{state:JSON.parse(JSON.stringify(s,(key,value)=>key==='data'&&typeof value==='string'&&value.startsWith('data:application/pdf;')?undefined:value)),version:c.version,estimates:Object.fromEntries(s.items.map(i=>[i.id,{average:avgCost(s,i.id),recipe:recipeCost(s,i.id)}]))})}
 if(path==='/api/planning'&&req.method==='GET')return send(res,200,{rows:forecast(JSON.parse(company().state),url.searchParams.get('date'))});
 if(path==='/api/suggest'&&req.method==='GET'){
  const s=JSON.parse(company().state),date=url.searchParams.get('date'),rid=url.searchParams.get('recipe');let requirements,sector;
  if(rid){const r=s.recipes.find(x=>x.id===rid);if(!r)throw Error('Elegí una receta.');const batches=Number(url.searchParams.get('batches'));requirements=r.components.map(x=>({itemId:x.itemId,qty:x.qty*batches}));sector=r.sectorId;}
  else requirements=[{itemId:url.searchParams.get('item'),qty:Number(url.searchParams.get('qty'))}];
  return send(res,200,suggestLots(s,requirements,date,sector));
 }
 if(path==='/api/report'&&req.method==='GET')return send(res,200,report(JSON.parse(company().state),url.searchParams.get('month')));
 if(path==='/api/trace'&&req.method==='GET')return send(res,200,trace(JSON.parse(company().state),url.searchParams.get('lot')));
 if(path==='/api/audit'&&req.method==='GET')return send(res,200,{rows:db.prepare('SELECT at,operation,detail FROM audit WHERE company_id=? ORDER BY at DESC LIMIT 500').all(u.company_id)});
 if(path==='/api/backup'&&req.method==='GET'){const c=company();return send(res,200,{format:'gestion-integral-v2',company:c.name,version:c.version,state:JSON.parse(c.state)})}
 if(path==='/api/action'&&req.method==='POST'){
  const p=await body(req);const result=tx(()=>{const c=company();if(p.version!==c.version){const e=Error('Otro usuario modificó la empresa. Actualizá la pantalla y revisá los datos antes de guardar.');e.status=409;throw e}const s=JSON.parse(c.state),result=operate(s,p.op,p.data||{});if(['master','recipe'].includes(p.op)){const attachments=p.data?.attachments||[];if(!Array.isArray(attachments)||attachments.length>3)throw Error('Documentos inválidos.');for(const doc of attachments)operate(s,'document',{...doc,collection:p.op==='recipe'?'items':p.data.collection,recordId:p.op==='recipe'?result.itemId:result.id});}db.prepare('UPDATE companies SET state=?,version=version+1 WHERE id=?').run(JSON.stringify(s),c.id);log(u,p.op,result);return{result,version:c.version+1}});return send(res,200,result)
 }
 return send(res,404,{error:'Ruta no disponible.'});
}catch(e){const msg=e.message.includes('UNIQUE constraint')?'Ese nombre de usuario ya existe.':e.message;send(res,e.status||400,{error:msg})}});
server.listen(PORT,HOST,()=>{
 if(PORT===0)PUBLIC=`http://localhost:${server.address().port}`;
 console.log(`Gestión Integral disponible en ${PUBLIC}`);
 if(process.send)process.send({type:'ready',url:PUBLIC});
});
if(process.send){
 let closing=false;
 const close=()=>{if(closing)return;closing=true;server.close(()=>{db.close();process.exit(0)});server.closeIdleConnections();};
 process.on('message',m=>{if(m?.type==='shutdown')close()});
 process.on('disconnect',close);
}
