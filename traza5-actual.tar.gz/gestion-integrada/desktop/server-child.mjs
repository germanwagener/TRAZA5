process.env.HOST='127.0.0.1';
process.env.PORT='0';
delete process.env.PUBLIC_ORIGIN;
await import('../server.mjs');
