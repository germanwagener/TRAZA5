import {DatabaseSync,backup} from 'node:sqlite';
import {existsSync,renameSync,rmSync,mkdirSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
const source=process.env.IMPORT_SOURCE,target=process.env.DB_PATH;
if(!source||!target||resolve(source)===resolve(target))throw Error('Elegí la base del programa anterior, en otra carpeta.');
mkdirSync(dirname(target),{recursive:true});
if(existsSync(target)){
 const previous=new DatabaseSync(target,{readOnly:true});
 try{if(previous.prepare('SELECT count(*) AS n FROM users').get().n)throw Error('Ya existen usuarios en esta copia. No se reemplazaron los datos.');}finally{previous.close()}
}
const db=new DatabaseSync(source,{readOnly:true});const staged=target+'.importando';
try{
 if(db.prepare('PRAGMA integrity_check').get().integrity_check!=='ok')throw Error('La base anterior necesita revisión. No se modificó el original.');
 for(const t of ['companies','users','sessions','audit'])db.prepare('SELECT 1 FROM '+t+' LIMIT 1').get();
 if(!db.prepare("SELECT id FROM users WHERE role='admin'").get())throw Error('La base elegida no tiene un administrador.');
 await backup(db,staged);
}finally{db.close()}
for(const suffix of ['-wal','-shm'])rmSync(target+suffix,{force:true});
renameSync(staged,target);
console.log('Datos copiados correctamente.');
