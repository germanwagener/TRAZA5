const {app,BrowserWindow,Menu,ipcMain,dialog,session}=require('electron');
const {spawn,execFile}=require('node:child_process');
const {join,dirname}=require('node:path');
const {pathToFileURL}=require('node:url');
const {mkdirSync,appendFileSync}=require('node:fs');
const appRoot=join(__dirname,'..');
const portableRoot=app.isPackaged?dirname(process.execPath):appRoot;
const dbPath=join(portableRoot,'data','gestion.sqlite');
const nodePath=process.platform==='win32'?join(appRoot,'runtime','node.exe'):process.env.DESKTOP_TEST_NODE;
let win,child,origin='',quitting=false,shutdown=false,setupBusy=false;
const setupURL=pathToFileURL(join(__dirname,'setup.html')).href;
app.setName('Consultora en Alimentos');
app.setAppUserModelId('ar.consultoraenalimentos.gestion');
function env(){return {...process.env,DB_PATH:dbPath}}
function run(script,args=[],extra={}){return new Promise((resolve,reject)=>execFile(nodePath,[join(appRoot,script),...args],{env:{...env(),...extra},windowsHide:true,timeout:45000},(error,stdout,stderr)=>error?reject(Error(stderr||error.message)):resolve(stdout.trim())))}
function errorBox(message){try{appendFileSync(join(portableRoot,'ERROR-ESCRITORIO.txt'),new Date().toISOString()+'\n'+message+'\n')}catch{}dialog.showErrorBox('Gestión Integral',message)}
function setupCaller(event){return win&&!win.isDestroyed()&&event.sender===win.webContents&&event.senderFrame===win.webContents.mainFrame&&event.senderFrame.url===setupURL}
async function openSystem(){
 if(child)return;
 await new Promise((resolve,reject)=>{
  let ready=false,stderr='';
  child=spawn(nodePath,[join(__dirname,'server-child.mjs')],{env:env(),windowsHide:true,stdio:['ignore','ignore','pipe','ipc']});
  const timer=setTimeout(()=>reject(Error('El programa tardó demasiado en iniciar. Cerralo y volvé a abrirlo.')),20000);
  child.stderr.on('data',data=>stderr+=data);
  child.once('error',error=>{clearTimeout(timer);reject(error)});
  child.on('message',msg=>{if(msg?.type==='ready'&&!ready){ready=true;clearTimeout(timer);origin=msg.url;resolve()}});
  child.on('exit',()=>{clearTimeout(timer);child=null;if(!ready)reject(Error(stderr||'No se pudo iniciar la base de datos.'));else if(!quitting){errorBox('El motor del programa se cerró. Los datos guardados se conservan. Volvé a abrir la aplicación.');app.quit()}});
 });
 if(!quitting&&win&&!win.isDestroyed())await win.loadURL(origin);
}
ipcMain.handle('setup:create',async(event,values)=>{
 if(!setupCaller(event)||setupBusy)return {error:'Operación no disponible.'};
 setupBusy=true;
 try{
  const username=String(values?.username||'').trim().toLowerCase(),pass=values?.password;
  if(!/^[a-z0-9_.-]{3,60}$/.test(username))return {error:'Usuario: de 3 a 60 letras, números, puntos o guiones.'};
  if(typeof pass!=='string'||pass.length<4||pass.length>128)return {error:'La contraseña debe tener entre 4 y 128 caracteres.'};
  if(pass!==values.confirmation)return {error:'Las contraseñas no coinciden.'};
  await run('server.mjs',['--create-admin'],{ADMIN_USER:username,ADMIN_PASSWORD:pass});
  await openSystem();return {ok:true};
 }catch(e){return {error:e.message}}finally{setupBusy=false}
});
ipcMain.handle('setup:import',async(event)=>{
 if(!setupCaller(event)||setupBusy)return {error:'Operación no disponible.'};setupBusy=true;
 try{
  const choice=await dialog.showOpenDialog(win,{title:'Elegir gestion.sqlite de la carpeta data anterior',properties:['openFile'],filters:[{name:'Base de Gestión Integral',extensions:['sqlite']}]});
  if(choice.canceled)return {canceled:true};
  await run('desktop/import-data.mjs',[],{IMPORT_SOURCE:choice.filePaths[0]});await openSystem();return {ok:true};
 }catch(e){return {error:e.message}}finally{setupBusy=false}
});
if(!app.requestSingleInstanceLock()){app.quit()}else{
 app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.show();win.focus()}});
 app.whenReady().then(async()=>{
  mkdirSync(join(portableRoot,'data'),{recursive:true});
  Menu.setApplicationMenu(null);
  session.defaultSession.setPermissionRequestHandler((_webContents,_permission,callback)=>callback(false));
  win=new BrowserWindow({title:'Consultora en Alimentos · Gestión Integral',width:1280,height:850,minWidth:800,minHeight:600,backgroundColor:'#f3f6f4',icon:join(appRoot,'public','assets','logo.png'),autoHideMenuBar:true,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,preload:join(__dirname,'preload.cjs')}});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  win.webContents.on('will-navigate',(event,url)=>{if(url!==setupURL&&(!origin||new URL(url).origin!==origin))event.preventDefault()});
  win.webContents.on('will-attach-webview',event=>event.preventDefault());
  win.webContents.on('did-fail-load',(_event,code,description)=>{if(code!==-3&&!quitting)errorBox('No se pudo cargar la pantalla: '+description)});
  if(await run('server.mjs',['--has-admin'])==='yes')await openSystem();else await win.loadFile(join(__dirname,'setup.html'));
 }).catch(e=>{errorBox(e.message);app.quit()});
}
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',event=>{
 quitting=true;if(!child||shutdown)return;
 event.preventDefault();shutdown=true;
 const processToClose=child;
 const timer=setTimeout(()=>{processToClose.kill();app.quit()},3500);
 processToClose.once('exit',()=>{clearTimeout(timer);app.quit()});
 if(processToClose.connected)processToClose.send({type:'shutdown'});else processToClose.kill();
});
