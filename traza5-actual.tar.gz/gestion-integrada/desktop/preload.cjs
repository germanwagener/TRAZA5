const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('desktopSetup',{
 create:values=>ipcRenderer.invoke('setup:create',values),
 importPrevious:()=>ipcRenderer.invoke('setup:import')
});
