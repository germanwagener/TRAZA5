const defaults = {businessName:'',taxId:'',address:'',phone:'',email:'',heading:'REMITO',prefix:'0001',footer:'Recibí la mercadería detallada en buen estado.',signatureLabel:'Firma y aclaración de quien recibe',showPrices:false};
export function deliverySettings(value={},company='') {
 const result={};
 for(const [key,fallback] of Object.entries(defaults)) {
  const v=value[key]??(key==='businessName'?company:fallback);
  if(key==='showPrices'){result[key]=v===true;continue;}
  if(typeof v!=='string'||v.length>(key==='footer'?2000:300))throw Error('Datos del remito inválidos o demasiado largos.');
  result[key]=v.trim();
 }
 if(!result.businessName||!result.heading)throw Error('Completá el nombre del emisor y el título del remito.');
 if(!/^\d{4}$/.test(result.prefix))throw Error('El punto de emisión debe tener cuatro dígitos.');
 const logo=value.logo||'';
 if(typeof logo!=='string'||logo.length>500000||(logo&&!/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(logo)))throw Error('El logo debe ser un JPG válido de tamaño reducido.');
 if(logo){const bytes=Buffer.from(logo.split(',')[1],'base64');if(bytes[0]!==255||bytes[1]!==216||bytes[2]!==255)throw Error('El archivo no es un JPG.');}
 result.logo=logo;
 return result;
}
export function createDelivery(s,sale) {
 const settings=deliverySettings(s.deliverySettings,s.company);
 const customer=s.customers.find(x=>x.id===sale.customerId)||{};
 const product=s.items.find(x=>x.id===sale.itemId)||{};
 const sequence=(s.deliveryCounter||0)+1;
 if(!Number.isSafeInteger(sequence)||sequence>99999999)throw Error('Se agotó la numeración de remitos.');
 s.deliveryCounter=sequence;
 return {number:settings.prefix+'-'+String(sequence).padStart(8,'0'),date:sale.date,settings,
  customer:Object.fromEntries(['name','taxId','address','phone'].map(k=>[k,String(customer[k]||'')])),
  lines:[{description:product.name||'',unit:product.unit||'',qty:sale.qty,unitPrice:sale.unitPrice,baseUnitPrice:sale.baseUnitPrice??sale.unitPrice,discountPercent:sale.discountPercent||0,
   lots:sale.inputs.map(x=>({code:s.lots.find(l=>l.id===x.lotId)?.code||'',qty:x.qty}))}],note:sale.note||''};
}
