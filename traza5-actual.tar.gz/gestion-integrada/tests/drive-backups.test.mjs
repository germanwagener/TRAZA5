import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,readFileSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {randomBytes,createHash} from 'node:crypto';
import {driveBackups} from '../drive-backups.mjs';
import {backupDay} from '../backups.mjs';
test('Drive: OAuth state, encrypted token, one daily copy, retry and cloud recovery',async()=>{
 const directory=mkdtempSync(join(tmpdir(),'traza-drive-test-'));writeFileSync(join(directory,'recovery.key'),randomBytes(32));
 const local=new Map(),remote=new Map();let fail=false,uploads=0,metadata;
 const store={list:()=>[...local.keys()].map(name=>({name,date:name.slice(6,16)})),create:()=>{const name=`Traza_${backupDay()}_diario-test.respaldo.enc`;local.set(name,Buffer.from('encrypted-test-content'));return{name}},bytes:n=>local.get(n),importBytes:(n,b)=>local.set(n,b)};
 const response=x=>new Response(JSON.stringify(x));
 const fetcher=async(url,o={})=>{
  if(fail)return new Response('',{status:503});
  if(url.includes('/token'))return response({access_token:'access',refresh_token:'private-refresh'});
  if(url.includes('/about?'))return response({user:{emailAddress:'consultora.alimentos.ros@gmail.com'}});
  if(url.includes('uploadType=resumable')){metadata=JSON.parse(o.body);return new Response('',{headers:{location:'https://www.googleapis.com/upload/session'}})}
  if(url.endsWith('/upload/session')){uploads++;const f={id:'file1',name:metadata.name,md5Checksum:createHash('md5').update(o.body).digest('hex'),bytes:Buffer.from(o.body)};remote.set(f.name,f);return response(f)}
  if(url.endsWith('?alt=media'))return new Response([...remote.values()][0].bytes);
  if(o.method==='POST')return response({id:'folder1'});
  return response({files:[...remote.values()]});
 };
 const args={directory,store,origin:'https://traza.example',env:{GOOGLE_CLIENT_ID:'id',GOOGLE_CLIENT_SECRET:'secret'},fetcher};
 try{
  let d=driveBackups(args);const auth=new URL(d.start('admin'));
  assert.equal(auth.searchParams.get('scope'),'https://www.googleapis.com/auth/drive.file');assert.ok(auth.searchParams.get('code_challenge'));
  await assert.rejects(()=>d.finish(new URLSearchParams({state:'forged',code:'x'}),()=>true));
  await d.finish(new URLSearchParams({state:auth.searchParams.get('state'),code:'code'}),()=>true);
  assert.equal(readFileSync(join(directory,'drive.config.enc')).includes(Buffer.from('private-refresh')),false);
  await d.sync();assert.equal(uploads,1);assert.equal(d.status().connected,true);assert.ok(d.status().lastSuccess);
  d=driveBackups(args);await d.sync();assert.equal(uploads,1);
  const name=store.list()[0].name;local.clear();assert.equal((await d.list())[0].drive,true);await d.ensure(name);assert.equal(local.get(name).toString(),'encrypted-test-content');
  fail=true;await d.sync();assert.match(d.status().error,/503/);fail=false;await d.sync();assert.equal(d.status().error,null);
 }finally{rmSync(directory,{recursive:true,force:true})}
});
