import {test} from 'node:test';import assert from 'node:assert/strict';import {empty,operate} from '../domain.mjs';
const state=()=>{const s=empty('Prueba');s.items=[{id:'i',kind:'raw',name:'Queso',supplierIds:[]}];s.suppliers=[{id:'p',name:'Proveedor'}];return s};
const data={date:'2026-09-10',itemId:'i',qty:2,supplierId:'p',supplierLot:'L1'};
test('Ingreso permite precio vacío u omitido y lo identifica como pendiente',()=>{for(const unitCost of ['',undefined]){const s=state(),r=operate(s,'purchase',{...data,unitCost});assert.equal(r.unitCost,0);assert.equal(r.pricePending,true);assert.equal(s.lots[0].remaining,2);}const r=operate(state(),'purchase',{...data,unitCost:0});assert.equal(r.pricePending,false);});
test('Proveedor faltante genera aviso concreto y no crea ingreso ni lote',()=>{const s=state();assert.throws(()=>operate(s,'purchase',{...data,supplierId:''}),/Seleccioná un proveedor/);assert.equal(s.purchases.length,0);assert.equal(s.lots.length,0);});
