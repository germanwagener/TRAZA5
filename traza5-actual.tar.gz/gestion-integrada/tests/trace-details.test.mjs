import {test} from 'node:test';
import assert from 'node:assert/strict';
import {trace,operate} from '../domain.mjs';
import {scenario} from './fixtures/trace-scenario.mjs';
test('Todos los consumos reales: varios lotes, cinco ingredientes y subproducto de otro sector',()=>{
 const {s,raw,a,b,production,sp}=scenario(),before=JSON.stringify(s),t=trace(s,production.lotId);
 assert.equal(t.consumptions.length,9);assert.equal(t.warnings.length,0);
 const direct=t.consumptions.filter(x=>x.parentLotId===production.lotId);assert.equal(direct.length,6);assert.equal(new Set(direct.map(x=>x.itemId)).size,5);
 const flour=direct.filter(x=>x.itemId===raw.Harina.id);assert.deepEqual(flour.map(x=>[x.lotId,x.qty,x.supplierLot]),[[a.lotId,1,'HAR-A'],[b.lotId,1,'HAR-B']]);
 assert.equal(t.consumptions.find(x=>x.parentLotId===sp.lotId&&x.lotId===a.lotId).qty,2);
 assert.equal(t.consumptions.find(x=>x.lotId===sp.lotId).qty,2);assert.equal(t.root.remaining,6);assert.equal(t.dispatchedQty,3);assert.equal(t.losses[0].qty,1);
 assert.ok(t.consumptions.every(x=>x.date&&x.expiry&&x.supplier));assert.equal(t.transfers.length,3);assert.equal(JSON.stringify(s),before);
 assert.equal(trace(s,a.lotId).dispatches[0].qty,3);assert.equal(trace(s,a.lotId).dispatches.length,1);
});
test('Cambiar receta no inventa consumos para lotes históricos',()=>{
 const {s,recipe,production}=scenario();const extra=operate(s,'master',{collection:'items',name:'Sal nueva',kind:'raw',unit:'kg'});
 operate(s,'recipe',{...recipe,components:[...recipe.components,{itemId:extra.id,qty:1}]});const t=trace(s,production.lotId);
 assert.equal(t.recipeComparison.changed,true);assert.deepEqual(t.recipeComparison.currentOnly,['Sal nueva']);assert.equal(t.consumptions.length,9);assert.ok(!t.consumptions.some(x=>x.itemId===extra.id));assert.equal(t.recipeComparison.historicalVersion,1);
});
test('Historial incompleto se informa y no se rellena desde la receta',()=>{
 const {s,production}=scenario();s.productions.find(x=>x.id===production.id).inputs.pop();const t=trace(s,production.lotId);
 assert.equal(t.incomplete,true);assert.ok(t.warnings.some(x=>x.code==='quantity_mismatch'));assert.equal(t.consumptions.length,5);
});
test('Lote ausente y referencias circulares no ocultan el resto ni bloquean la consulta',()=>{
 const {s,production,sp}=scenario();s.productions.find(x=>x.id===sp.id).inputs.push({lotId:production.lotId,qty:1},{lotId:'ausente',itemId:'ausente',qty:2});const t=trace(s,production.lotId);
 assert.ok(t.warnings.some(x=>x.code==='cycle'));assert.ok(t.warnings.some(x=>x.code==='missing_lot'));assert.equal(t.consumptions.length,11);
});
test('El lote se identifica por su registro aunque dos códigos sean iguales',()=>{
 const {s,production}=scenario();s.lots.push({...s.lots.find(x=>x.id===production.lotId),id:'otro',remaining:99});const t=trace(s,production.lotId);assert.equal(t.root.remaining,6);assert.ok(!t.ancestors.includes('otro'));assert.ok(!t.descendants.includes('otro'));
});
