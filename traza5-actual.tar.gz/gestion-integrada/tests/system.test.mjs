import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawn,spawnSync} from 'node:child_process';
import {empty,operate,report,trace,avgCost} from '../domain.mjs';
function run(s,op,data){const copy=structuredClone(s),r=operate(copy,op,data);Object.assign(s,copy);return r}
function fixtures(){const s=empty('Ejemplo');const sector=run(s,'master',{collection:'sectors',name:'Cocina'}),supplier=run(s,'master',{collection:'suppliers',name:'Molino'}),customer=run(s,'master',{collection:'customers',name:'Cliente'});const raw=run(s,'master',{collection:'items',name:'Harina',kind:'raw',unit:'kg'}),sub=run(s,'master',{collection:'items',name:'Masa',kind:'subproduct',unit:'kg'}),product=run(s,'master',{collection:'items',name:'Pizza',kind:'product',unit:'u'});return{s,sector,supplier,customer,raw,sub,product}}
test('Circuito: dos compras, subproducto, producción, despacho, costos y traza bidireccional',()=>{
 const {s,sector,supplier,customer,raw,sub,product}=fixtures(),date='2026-09-01',expiry='2026-12-01';
 const receipt=(q,c,code)=>run(s,'purchase',{date,itemId:raw.id,supplierId:supplier.id,supplierLot:code,qty:q,unitCost:c,sectorId:sector.id,expiry});
 const a=receipt(10,100,'A'),b=receipt(10,200,'B');
 const r1=run(s,'recipe',{itemId:sub.id,sectorId:sector.id,yield:5,components:[{itemId:raw.id,qty:5}]});
 const p1=run(s,'produce',{date,recipeId:r1.id,batches:1,qty:5,expiry,allocations:[{lotId:a.lotId,qty:3},{lotId:b.lotId,qty:2}]});assert.equal(p1.unitCost,150);assert.equal(avgCost(s,raw.id),150);
 const r2=run(s,'recipe',{itemId:product.id,sectorId:sector.id,yield:10,components:[{itemId:sub.id,qty:5}]});
 const p2=run(s,'produce',{date,recipeId:r2.id,batches:1,qty:10,expiry,allocations:[{lotId:p1.lotId,qty:5}]});assert.equal(p2.unitCost,75);
 const sale=run(s,'sale',{date,itemId:product.id,customerId:customer.id,unitPrice:200,allocations:[{lotId:p2.lotId,qty:4}]});assert.equal(sale.unitCost,75);
 run(s,'expense',{date,name:'Alquiler',type:'fixed',amount:100});run(s,'expense',{date,name:'Gasto específico',type:'fixed',amount:20,itemId:product.id});
 const r=report(s,'2026-09');assert.equal(r.net,380);assert.equal(r.products[0].net,380);assert.equal(r.products[0].assigned,120);
 assert.equal(trace(s,p2.lotId).purchases.length,2);assert.equal(trace(s,a.lotId).sales[0].customerId,customer.id);assert.equal(s.lots.find(l=>l.id===p1.lotId).remaining,0);
 // Historical recipe and sale cost must not change when recipes and prices change.
 run(s,'recipe',{itemId:product.id,sectorId:sector.id,yield:20,components:[{itemId:sub.id,qty:5}]});receipt(20,900,'C');assert.equal(s.productions.find(x=>x.id===p2.id).recipe.yield,10);assert.equal(report(s,'2026-09').cogs,300);
 const before=JSON.stringify(s);assert.throws(()=>run(s,'sale',{date,itemId:product.id,customerId:customer.id,unitPrice:1,allocations:[{lotId:p2.lotId,qty:999}]}),/Stock insuficiente/);assert.equal(JSON.stringify(s),before);
 run(s,'status',{lotId:p2.lotId,status:'BLOQUEADO',reason:'Control'});assert.throws(()=>run(s,'sale',{date,itemId:product.id,customerId:customer.id,unitPrice:1,allocations:[{lotId:p2.lotId,qty:1}]}),/no liberado/);
 assert.throws(()=>run(s,'purchase',{date:'2026-08-01',itemId:raw.id,supplierId:supplier.id,supplierLot:'D',qty:1,unitCost:1}),/orden de fecha/);
});
test('Sectores, vencimiento, ciclos y gastos sin ventas',()=>{
 const {s,sector,supplier,raw,sub,product}=fixtures();const r=run(s,'recipe',{itemId:sub.id,sectorId:sector.id,yield:1,components:[{itemId:raw.id,qty:1}]});
 const a=run(s,'purchase',{date:'2026-09-01',itemId:raw.id,supplierId:supplier.id,supplierLot:'A',qty:3,unitCost:2,expiry:'2026-09-02'});
 assert.throws(()=>run(s,'produce',{date:'2026-09-01',recipeId:r.id,batches:1,qty:1,allocations:[{lotId:a.lotId,qty:1}]}),/Trasladá/);
 run(s,'transfer',{date:'2026-09-01',lotId:a.lotId,sectorId:sector.id});assert.throws(()=>run(s,'produce',{date:'2026-09-03',recipeId:r.id,batches:1,qty:1,allocations:[{lotId:a.lotId,qty:1}]}),/vencido/);
 run(s,'recipe',{itemId:product.id,sectorId:sector.id,yield:1,components:[{itemId:sub.id,qty:1}]});assert.throws(()=>run(s,'recipe',{itemId:sub.id,sectorId:sector.id,yield:1,components:[{itemId:product.id,qty:1}]}),/ciclo/);
 run(s,'expense',{date:'2026-09-01',name:'Gasto',type:'fixed',amount:10});const rr=report(s,'2026-09');assert.equal(rr.net,-10);assert.equal(rr.unallocated,10);
});
test('Servidor: aislamiento, permisos, reset e invalidación de sesiones',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'gestion-test-')),port=31847,origin=`http://localhost:${port}`,env={...process.env,DB_PATH:join(dir,'db.sqlite'),PORT:String(port),PUBLIC_ORIGIN:origin,ADMIN_USER:'admin',ADMIN_PASSWORD:'ClaveInicial-123456'};
 const setup=spawnSync(process.execPath,['server.mjs','--create-admin'],{cwd:new URL('..',import.meta.url),env,encoding:'utf8'});assert.equal(setup.status,0,setup.stderr);
 const child=spawn(process.execPath,['server.mjs'],{cwd:new URL('..',import.meta.url),env,stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{child.stdout.once('data',resolve);child.once('error',reject);child.once('exit',c=>reject(Error('server exit '+c)))});
 async function req(path,data,cookie='',otherOrigin=origin){const res=await fetch(origin+'/api/'+path,{method:data?'POST':'GET',headers:{...(data?{'Content-Type':'application/json',Origin:otherOrigin}:{}),Cookie:cookie},body:data?JSON.stringify(data):undefined});return{status:res.status,data:await res.json(),cookie:res.headers.get('set-cookie')?.split(';')[0]}}
 try{
 const login=await req('login',{username:'admin',password:env.ADMIN_PASSWORD});assert.equal(login.status,200);const ac=login.cookie;
 assert.equal((await req('state',null,ac)).status,403);
 const create=(username)=>req('admin',{op:'create',username,password:'ClienteTemporal-1234',companyName:username},ac);
 assert.equal((await create('empresa_a')).status,200);assert.equal((await create('empresa_b')).status,200);
 let a=await req('login',{username:'empresa_a',password:'ClienteTemporal-1234'});assert.equal((await req('state',null,a.cookie)).status,403);
 assert.equal((await req('password',{oldPassword:'ClienteTemporal-1234',newPassword:'ClaveNuevaEmpresaA-1234'},a.cookie)).status,200);assert.equal((await req('me',null,a.cookie)).status,401);
 a=await req('login',{username:'empresa_a',password:'ClaveNuevaEmpresaA-1234'});
 let b=await req('login',{username:'empresa_b',password:'ClienteTemporal-1234'});await req('password',{oldPassword:'ClienteTemporal-1234',newPassword:'ClaveNuevaEmpresaB-1234'},b.cookie);b=await req('login',{username:'empresa_b',password:'ClaveNuevaEmpresaB-1234'});
 assert.equal((await req('action',{op:'master',version:0,data:{collection:'customers',name:'Privado A'}},a.cookie)).status,200);
 const ast=await req('state',null,a.cookie),bst=await req('state',null,b.cookie);assert.equal(ast.data.state.customers.length,1);assert.equal(bst.data.state.customers.length,0);
 assert.equal((await req('action',{op:'master',version:0,data:{collection:'customers',id:ast.data.state.customers[0].id,name:'Robo'}},b.cookie)).status,400);
 assert.equal((await req('admin',null,b.cookie)).status,404);
 assert.equal((await req('action',{op:'master',version:0,data:{collection:'customers',name:'Viejo'}},a.cookie)).status,409);
 assert.equal((await req('action',{op:'master',version:1,data:{collection:'customers',name:'CSRF'}},a.cookie,'https://otro.example')).status,403);
 const pdf='data:application/pdf;base64,'+Buffer.from('%PDF-1.7\nPrueba\n%%EOF').toString('base64');
 const saved=await req('action',{op:'master',version:1,data:{collection:'items',name:'Con RNPA',kind:'raw',unit:'kg',attachments:[{label:'RNPA',name:'prueba.pdf',data:pdf}]}},a.cookie);assert.equal(saved.status,200);
 const withDocs=(await req('state',null,a.cookie)).data;const ri=withDocs.state.items[0],doc=ri.documents[0];assert.equal(doc.data,undefined);
 const url=origin+'/api/document?collection=items&record='+ri.id+'&id='+doc.id;
 const opened=await fetch(url,{headers:{Cookie:a.cookie}});assert.equal(opened.status,200);assert.equal(opened.headers.get('content-type'),'application/pdf');assert.equal((await opened.text()).slice(0,5),'%PDF-');
 assert.equal((await fetch(url,{headers:{Cookie:b.cookie}})).status,404);assert.equal((await fetch(url)).status,401);
 assert.equal((await req('backup',null,a.cookie)).data.state.items[0].documents[0].data,pdf);
 const invalid=await req('action',{op:'master',version:2,data:{collection:'items',name:'Debe revertirse',kind:'raw',unit:'kg',attachments:[{label:'RNPA',name:'falso.pdf',data:'data:application/pdf;base64,SG9sYQ=='}]}},a.cookie);assert.equal(invalid.status,400);assert.equal((await req('state',null,a.cookie)).data.state.items.length,1);assert.equal((await req('state',null,a.cookie)).data.version,2);
 const users=(await req('admin',null,ac)).data.users;const aid=users.find(x=>x.username==='empresa_a').id;
 await req('admin',{op:'reset',userId:aid,password:'OtraTemporal-123456'},ac);assert.equal((await req('me',null,a.cookie)).status,401);assert.equal((await req('login',{username:'empresa_a',password:'ClaveNuevaEmpresaA-1234'})).status,401);
 assert.equal((await req('login',{username:'empresa_a',password:'OtraTemporal-123456'})).status,200);
 const bid=users.find(x=>x.username==='empresa_b').id;await req('admin',{op:'block',userId:bid,blocked:true},ac);assert.equal((await req('me',null,b.cookie)).status,401);
 assert.equal((await req('login',{username:'empresa_b',password:'ClaveNuevaEmpresaB-1234'})).status,401);
 }finally{child.kill();await new Promise(r=>child.once('exit',r));rmSync(dir,{recursive:true,force:true})}
});
