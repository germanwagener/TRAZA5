import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn,spawnSync} from 'node:child_process';
import {mkdtempSync,rmSync,existsSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=dirname(dirname(fileURLToPath(import.meta.url)));
test('Escritorio: clave de 4, puerto automático, cierre limpio e importación',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'gestion-desktop-'));let child;
 const dbPath=join(dir,'original','gestion.sqlite');
 const setup=p=>spawnSync(process.execPath,[join(root,'server.mjs'),'--create-admin'],{env:{...process.env,DB_PATH:dbPath,ADMIN_USER:'admin',ADMIN_PASSWORD:p},encoding:'utf8'});
 try{
  assert.notEqual(setup('abc').status,0);assert.equal(setup('abcd').status,0);
  const start=path=>new Promise((resolve,reject)=>{
   child=spawn(process.execPath,[join(root,'desktop','server-child.mjs')],{env:{...process.env,DB_PATH:path},stdio:['ignore','ignore','pipe','ipc']});
   const timeout=setTimeout(()=>reject(Error('No inició')),10000);
   child.on('message',m=>{if(m.type==='ready'){clearTimeout(timeout);resolve(m.url)}});
   child.on('error',reject);child.on('exit',()=>{clearTimeout(timeout);reject(Error('Cierre anticipado'))});
  });
  const stop=()=>new Promise(r=>{child.once('exit',r);child.send({type:'shutdown'})});
  let url=await start(dbPath);assert.notEqual(new URL(url).port,'0');
  const post=(path,data)=>fetch(url+'/api/'+path,{method:'POST',headers:{Origin:url,'Content-Type':'application/json'},body:JSON.stringify(data)});
  let response=await post('login',{username:'admin',password:'abcd'});assert.equal(response.status,200);const cookie=response.headers.get('set-cookie').split(';')[0];
  response=await fetch(url+'/api/password',{method:'POST',headers:{Origin:url,'Content-Type':'application/json',Cookie:cookie},body:JSON.stringify({oldPassword:'abcd',newPassword:'efgh'})});assert.equal(response.status,200);
  await stop();assert.equal(child.exitCode,0);
  const target=join(dir,'new','gestion.sqlite');
  const copied=spawnSync(process.execPath,[join(root,'desktop','import-data.mjs')],{env:{...process.env,IMPORT_SOURCE:dbPath,DB_PATH:target},encoding:'utf8'});
  assert.equal(copied.status,0,copied.stderr);assert.ok(existsSync(dbPath));assert.ok(existsSync(target));
  url=await start(target);response=await post('login',{username:'admin',password:'efgh'});assert.equal(response.status,200);await stop();
  const denied=spawnSync(process.execPath,[join(root,'desktop','import-data.mjs')],{env:{...process.env,IMPORT_SOURCE:dbPath,DB_PATH:target},encoding:'utf8'});assert.notEqual(denied.status,0);
 }finally{if(child&&child.exitCode===null)child.kill();rmSync(dir,{recursive:true,force:true})}
});
