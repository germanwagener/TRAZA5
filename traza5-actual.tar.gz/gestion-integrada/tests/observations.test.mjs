import {test} from 'node:test';
import assert from 'node:assert/strict';
import {empty,operate,trace} from '../domain.mjs';
test('Recetas directas, versión histórica, tres ingredientes y traza hacia clientes',()=>{
 const s=empty('Prueba'),run=(op,p)=>{const copy=structuredClone(s),r=operate(copy,op,p);Object.assign(s,copy);return r};
 const sec=run('master',{collection:'sectors',name:'Cocina'}),sup=run('master',{collection:'suppliers',name:'Molino'}),client=run('master',{collection:'customers',name:'Cliente'});
 const raws=['Harina','Sal','Agua'].map(name=>run('master',{collection:'items',name,kind:'raw',unit:'kg'}));
 const purchases=raws.map((i,n)=>run('purchase',{date:'2026-09-11',itemId:i.id,supplierId:sup.id,supplierLot:'ORIGEN-'+n,qty:20,unitCost:1,sectorId:sec.id,expiry:'2026-12-01'}));
 const sub=run('recipe',{name:'Masa directa',kind:'subproduct',unit:'kg',yield:3,sectorId:sec.id,shelfLifeDays:3,components:raws.slice(0,2).map(i=>({itemId:i.id,qty:1}))});
 const subp=run('produce',{date:'2026-09-11',recipeId:sub.id,batches:1,qty:3,allocations:purchases.slice(0,2).map(p=>({lotId:p.lotId,qty:1}))});
 const recipe=run('recipe',{name:'Pan directo',kind:'product',unit:'u',yield:10,sectorId:sec.id,shelfLifeDays:5,components:[{itemId:sub.itemId,qty:3},{itemId:raws[2].id,qty:1}]});
 const p=run('produce',{date:'2026-09-11',recipeId:recipe.id,batches:1,qty:10,allocations:[{lotId:subp.lotId,qty:3},{lotId:purchases[2].lotId,qty:1}]});
 run('sale',{date:'2026-09-11',customerId:client.id,itemId:recipe.itemId,unitPrice:12,allocations:[{lotId:p.lotId,qty:4}]});
 const t=trace(s,p.lotId);assert.equal(t.ancestors.length,5);assert.equal(t.purchases.length,3);assert.equal(t.sales[0].qty,4);assert.equal(s.lots.find(x=>x.id===p.lotId).remaining,6);assert.equal(trace(s,purchases[0].lotId).sales.length,1);
 run('recipe',{itemId:recipe.itemId,name:'Pan editado',kind:'product',unit:'u',yield:12,sectorId:sec.id,shelfLifeDays:6,components:recipe.components});assert.equal(s.items.filter(i=>i.id===recipe.itemId).length,1);assert.equal(p.recipe.yield,10);
 assert.throws(()=>run('recipe',{...recipe,name:'Duplicado',kind:'subproduct',unit:'u'}),/tipo o unidad/);
 assert.throws(()=>run('sale',{date:'2026-09-11',customerId:client.id,itemId:sub.itemId,unitPrice:1,allocations:[]}),/producto terminado/);
});
test('PDF opcional, validación de contenido, conservación al editar y respaldo',()=>{
 const s=empty('PDF'),i=operate(s,'master',{collection:'items',name:'Harina',kind:'raw',unit:'kg'});
 assert.equal(i.documents,undefined);const data='data:application/pdf;base64,'+Buffer.from('%PDF-1.7\nTest\n%%EOF').toString('base64');
 operate(s,'document',{collection:'items',recordId:i.id,label:'RNPA',name:'registro.pdf',data});
 operate(s,'master',{collection:'items',id:i.id,name:'Harina editada',kind:'raw',unit:'kg'});assert.equal(i.documents[0].data,data);assert.equal(JSON.parse(JSON.stringify(s)).items[0].documents.length,1);
 assert.throws(()=>operate(s,'document',{collection:'items',recordId:i.id,label:'RNPA',name:'falso.pdf',data:'data:application/pdf;base64,SG9sYQ=='}),/inválido/);
});

