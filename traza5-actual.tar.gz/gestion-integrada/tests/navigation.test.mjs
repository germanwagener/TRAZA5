import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {empty} from '../domain.mjs';
const source=readFileSync(new URL('../public/app.js',import.meta.url),'utf8');
function screen(fetch){
 const nodes=new Map();const events={};
 const get=s=>{if(!nodes.has(s))nodes.set(s,{innerHTML:'',textContent:'',value:'',setCustomValidity(v){this.validation=v},setAttribute(){},removeAttribute(){},querySelectorAll(){return []},insertAdjacentHTML(_,v){this.innerHTML+=v}});return nodes.get(s)};
 const context=vm.createContext({console,fetch,clearTimeout:()=>{},setTimeout:()=>{},document:{querySelector:get,querySelectorAll:()=>[],addEventListener:(name,fn)=>events[name]=fn}});
 vm.runInContext(source.slice(0,source.lastIndexOf('(async()=>')),context);
 return {nodes,context,run:code=>vm.runInContext(code,context),events};
}
test('Contraseña inicial: ninguna página accede a datos todavía nulos',async()=>{
 const ui=screen(()=>{throw Error('No se deben pedir datos antes del cambio de clave')});
 ui.run("user={role:'company',username:'prueba',mustChange:true};state=null");
 for(const page of ['items','suppliers','recipes','purchases','productions','sales','reports','trace']){
  await ui.run(`view=${JSON.stringify(page)};render()`);
  assert.match(ui.nodes.get('#content').innerHTML,/Cambiar contraseña inicial/);
  assert.ok(!ui.nodes.get('#shell').innerHTML.includes('data-view='));
 }
 await ui.events.click({target:{closest:()=>({dataset:{action:'sale'}})}});
 assert.match(ui.nodes.get('#content').innerHTML,/Cambiar contraseña inicial/);
});
test('Fallo de carga: permite reintentar y vuelve a habilitar navegación al recibir datos',async()=>{
 let failure=true;const state=empty('Empresa de prueba');
 const ui=screen(async()=>{if(failure)throw Error('Conexión interrumpida');return {ok:true,json:async()=>({state,version:0,estimates:{}})}});
 ui.run("user={role:'company',username:'prueba',mustChange:false};state=null;view='items'");
 await ui.run('render()');assert.match(ui.nodes.get('#content').innerHTML,/Reintentar carga/);
 assert.ok(!ui.nodes.get('#shell').innerHTML.includes('data-view='));
 failure=false;await ui.run('actions.retry()');
 assert.ok(ui.nodes.get('#shell').innerHTML.includes('data-view='));assert.match(ui.nodes.get('#content').innerHTML,/Sin registros/);
});

test('Búsqueda de clientes por código o nombre, sin acentos y sin archivados',()=>{const ui=screen();ui.run("state={customers:[{id:'a',code:'0012',name:'Almacén Norte'},{id:'b',name:'Mercado Sur'},{id:'c',code:'99',name:'Archivado',archived:true}]}");assert.equal(ui.run("customerLabel(state.customers[0])"),'0012 - Almacén Norte');assert.equal(ui.run("customerLabel(state.customers[1])"),'Mercado Sur');assert.equal(ui.run("matchingCustomers(state.customers,'0012')[0].id"),'a');assert.equal(ui.run("matchingCustomers(state.customers,'ALMACEN')[0].id"),'a');assert.equal(ui.run("matchingCustomers(state.customers,'sur')[0].id"),'b');assert.equal(ui.run("matchingCustomers(state.customers,'99').length"),0);ui.run('bindCustomerPicker()');ui.nodes.get('[name=customerId]').value='a';ui.nodes.get('[name=customerSearch]').value='sur';ui.nodes.get('[name=customerSearch]').oninput();assert.equal(ui.nodes.get('[name=customerId]').value,'');assert.match(ui.nodes.get('#customerOptions').innerHTML,/Mercado Sur/);assert.ok(!ui.nodes.get('#customerOptions').innerHTML.includes('Almacén Norte'));ui.nodes.get('[name=customerSearch]').onkeydown({key:'Enter',preventDefault(){}});assert.equal(ui.nodes.get('[name=customerId]').value,'b');assert.equal(ui.nodes.get('#customerOptions').hidden,true);});

test('Trazabilidad muestra observaciones del ingreso al consultar artículo o producto derivado',async()=>{const s=empty('Prueba');s.items=[{id:'raw',name:'Queso barra'},{id:'sub',name:'Relleno'},{id:'out',name:'Empanada'}];s.lots=[{id:'l1',itemId:'raw',code:'Q-1',date:'2026-09-01'},{id:'l2',itemId:'sub',code:'020926',date:'2026-09-02'},{id:'l3',itemId:'out',code:'030926',date:'2026-09-03'}];s.purchases=[{id:'p1',lotId:'l1',note:'Envase marcado\nRevisar <etiqueta>'},{id:'other',lotId:'other',note:'NO DEBE APARECER'}];for(const id of ['l1','l2','l3']){const ancestors=id==='l1'?['l1']:id==='l2'?['l2','l1']:['l3','l2','l1'];const ui=screen(async()=>({ok:true,json:async()=>({ancestors,descendants:[id],productions:[],sales:[],transfers:[]})}));ui.context.fixture=s;ui.run('state=fixture');await ui.run('traceShow('+JSON.stringify(id)+')');const html=ui.nodes.get('#traceResult').innerHTML;assert.match(html,/Observaciones de los ingresos utilizados/);assert.match(html,/Envase marcado\nRevisar &lt;etiqueta&gt;/);assert.ok(!html.includes('NO DEBE APARECER'));}});

test('Botón de elaboración completa todos los campos de lotes con una sola consulta',async()=>{let calls=0;const ui=screen(async()=>{calls++;return {ok:true,json:async()=>({allocations:[{lotId:'a',qty:2},{lotId:'b',qty:3}],shortages:[]})}});const inputs=[{dataset:{lot:'a'},value:0},{dataset:{lot:'b'},value:0},{dataset:{lot:'c'},value:9}];ui.context.document.querySelectorAll=()=>inputs;ui.run("state={items:[]}");await ui.run("fillSuggested('recipe=r&batches=1',true)");assert.equal(calls,1);assert.deepEqual(inputs.map(x=>x.value),[2,3,0]);assert.match(ui.nodes.get('#suggestNote').textContent,/todos los ingredientes/);});

test('Informes espera selección y reúne PDFs de ingredientes y proveedores',async()=>{const ui=screen();const s=empty('Inspección');s.items=[{id:'raw',name:'Harina',supplierIds:['sup'],documents:[{id:'d1',label:'RNPA',name:'harina.pdf'}]},{id:'sub',name:'Masa',documents:[{id:'d2',label:'RNPA',name:'masa.pdf'}]},{id:'out',name:'Pan',kind:'product',documents:[{id:'d3',label:'RNPA',name:'pan.pdf'}]}];s.suppliers=[{id:'sup',name:'Molino',documents:[{id:'d4',label:'RNE',name:'molino.pdf'}]}];s.recipes=[{id:'r1',itemId:'sub',components:[{itemId:'raw',qty:1}]},{id:'r2',itemId:'out',components:[{itemId:'sub',qty:2}]}];ui.context.fixture=s;ui.run("state=fixture;user={role:'company'};view='reports'");await ui.run('render()');assert.equal(ui.nodes.get('#reportResult'),undefined);const html=ui.run("recipeReport('pan')");for(const pdf of ['harina.pdf','masa.pdf','pan.pdf','molino.pdf'])assert.ok(html.includes(pdf));assert.equal(ui.run("recipeReport('inexistente')"),'<p>Sin recetas coincidentes.</p>');});
