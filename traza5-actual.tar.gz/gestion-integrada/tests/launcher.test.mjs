import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import net from 'node:net';
const root=dirname(dirname(fileURLToPath(import.meta.url)));
test('Arranque: corrige usuario, clave corta y repetición; conserva admin',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'gestion-start-'));
 const probe=net.createServer();await new Promise(r=>probe.listen(0,'127.0.0.1',r));const port=probe.address().port;await new Promise(r=>probe.close(r));
 let child;const env={...process.env,DB_PATH:join(dir,'db.sqlite'),PORT:String(port),PUBLIC_ORIGIN:`http://localhost:${port}`};
 async function start(steps){
  child=spawn(process.execPath,['iniciar.mjs'],{cwd:root,env,stdio:['pipe','pipe','pipe']});
  let all='',pending='',index=0;
  await new Promise((resolve,reject)=>{
   const timeout=setTimeout(()=>reject(Error('Tiempo agotado: '+all)),10000);
   child.on('exit',c=>{clearTimeout(timeout);reject(Error('Terminó: '+c+' '+all))});
   child.stdout.on('data',chunk=>{
    all+=chunk;pending+=chunk;
    if(index<steps.length&&pending.includes(steps[index][0])){const answer=steps[index++][1];pending='';child.stdin.write(answer+'\n');}
    if(all.includes('Gestión Integral disponible')){clearTimeout(timeout);resolve();}
   });child.stderr.on('data',c=>all+=c);
  });
  assert.equal(index,steps.length);
  assert.equal((await fetch(`http://127.0.0.1:${port}/`)).status,200);
  return all;
 }
 async function stop(){if(child&&child.exitCode===null){const done=new Promise(r=>child.once('exit',r));child.kill('SIGINT');await done;}}
 try{
  const out=await start([
   ['Usuario administrador: ','x'],['Usuario administrador: ','administrador'],
   ['Contraseña (','abc'],['Contraseña (','clave-larga-123'],
   ['Repetí la contraseña: ','otra-clave-123'],['Contraseña (','clave-larga-123'],
   ['Repetí la contraseña: ','clave-larga-123']
  ]);
  assert.match(out,/entre 4 y 128/);assert.match(out,/no coinciden/);assert.match(out,/Administrador creado correctamente/);
  const r=await fetch(`http://127.0.0.1:${port}/api/login`,{method:'POST',headers:{Origin:`http://localhost:${port}`,'Content-Type':'application/json'},body:JSON.stringify({username:'administrador',password:'clave-larga-123'})});assert.equal(r.status,200);
  await stop();const restart=await start([]);assert.ok(!restart.includes('Usuario administrador:'));
 }finally{await stop();rmSync(dir,{recursive:true,force:true});}
});
