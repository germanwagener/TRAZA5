import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {mkdtempSync,rmSync,readFileSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {backupDay,createBackupStore} from '../backups.mjs';

test('backup restores PDFs, accounts and audit atomically; retains current admin and invalidates sessions',()=>{
 const dir=mkdtempSync(join(tmpdir(),'traza-backup-')),db=new DatabaseSync(':memory:');
 try{
  db.exec(`PRAGMA foreign_keys=ON;
   CREATE TABLE companies(id TEXT PRIMARY KEY,name TEXT,state TEXT,version INTEGER);
   CREATE TABLE users(id TEXT PRIMARY KEY,username TEXT UNIQUE,password TEXT,role TEXT,company_id TEXT REFERENCES companies(id),blocked INTEGER,must_change INTEGER);
   CREATE TABLE sessions(token TEXT,user_id TEXT REFERENCES users(id),expires INTEGER);
   CREATE TABLE audit(id TEXT,at TEXT,user_id TEXT,company_id TEXT,operation TEXT,detail TEXT);
   CREATE TABLE attempts(key TEXT,count INTEGER,until INTEGER);
   INSERT INTO users VALUES('admin','admin','current-secret','admin',NULL,0,0);
   INSERT INTO companies VALUES('c','Empresa','{"items":[{"documents":[{"data":"data:application/pdf;base64,JVBERg=="}]}]}',5);
   INSERT INTO users VALUES('u','empresa','company-secret','company','c',0,0);
   INSERT INTO sessions VALUES('session','u',123);
   INSERT INTO audit VALUES('a','2026-09-17','u','c','test','{}');`);
  const store=createBackupStore(db,dir),backup=store.create();
  assert.equal(readFileSync(join(dir,backup.name)).includes(Buffer.from('company-secret')),false);
  db.exec(`UPDATE companies SET state='{"items":[]}',version=9; UPDATE users SET password='new-admin-secret' WHERE id='admin'`);
  const result=store.restore(backup.name,'admin');
  assert.match(db.prepare('SELECT state FROM companies').get().state,/JVBERg/);
  assert.equal(db.prepare('SELECT version FROM companies').get().version,10);
  assert.equal(db.prepare("SELECT password FROM users WHERE id='admin'").get().password,'new-admin-secret');
  assert.equal(db.prepare('SELECT count(*) n FROM sessions').get().n,0);
  assert.equal(store.list().length,2);
  assert.match(result.safety,/antes-restaurar/);
  store.restore(result.safety,'admin');assert.deepEqual(JSON.parse(db.prepare('SELECT state FROM companies').get().state),{items:[]});
  const bytes=readFileSync(join(dir,backup.name));bytes[25]^=1;writeFileSync(join(dir,backup.name),bytes);
  assert.throws(()=>store.restore(backup.name,'admin'));
  assert.deepEqual(JSON.parse(db.prepare('SELECT state FROM companies').get().state),{items:[]});
  assert.throws(()=>store.preview('../recovery.key'));
 }finally{db.close();rmSync(dir,{recursive:true,force:true})}
});
test('dates use Argentina time around midnight UTC',()=>{
 assert.equal(backupDay(new Date('2026-09-17T01:00:00Z')),'2026-09-16');
});
