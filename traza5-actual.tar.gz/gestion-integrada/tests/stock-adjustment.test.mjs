import {test} from 'node:test';
import assert from 'node:assert/strict';
import {empty,operate,adjustStock} from '../domain.mjs';

test('El ajuste autorizado cambia solamente el saldo real del lote y deja evidencia completa',()=>{
 const s=empty('Prueba'),sector=operate(s,'master',{collection:'sectors',name:'Depósito'}),raw=operate(s,'master',{collection:'items',name:'Harina',kind:'raw',unit:'kg'});
 const opening=operate(s,'opening',{date:'2026-09-20',itemId:raw.id,supplierLot:'INI-01',qty:10,unitCost:100,sectorId:sector.id,expiry:'2027-01-01'});
 const result=adjustStock(s,{date:'2026-09-20',lotId:opening.lotId,actualQty:7.25,reason:'Recuento físico semanal'});
 assert.equal(s.lots[0].remaining,7.25);assert.equal(result.previousQty,10);assert.equal(result.delta,-2.75);assert.equal(result.stockCorrection,true);assert.equal(s.adjustments.at(-1).reason,'Recuento físico semanal');
 assert.throws(()=>adjustStock(s,{date:'2026-09-19',lotId:opening.lotId,actualQty:8,reason:'Fecha anterior'}),/orden de fecha/);
});
