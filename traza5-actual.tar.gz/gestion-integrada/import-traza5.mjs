import {empty,recipeCost} from './domain.mjs';
const same=(a,b)=>String(a)===String(b);
const key=(kind,id)=>`traza5-${kind}-${id}`;
const n=(x,label,zero=false)=>{const v=Number(x);if(!Number.isFinite(v)||(zero?v<0:v<=0))throw Error(label+' inválido');return v};
const day=x=>{const d=String(x||'').slice(0,10);if(!/^\d{4}-\d{2}-\d{2}$/.test(d)||Number.isNaN(Date.parse(d)))throw Error('Fecha de TRAZA5 inválida');return d};
export function importTraza5(data,clientId){
 if(data?.format!=='traza5-export-v1')throw Error('El archivo no es una exportación de TRAZA5 compatible.');
 for(const name of ['clients','sectors','suppliers','products','product_suppliers','recipes','recipe_items','receipts','batches','batch_inputs'])if(!Array.isArray(data[name]))throw Error('Falta la tabla '+name);
 const client=data.clients.find(c=>same(c.id,clientId));if(!client)throw Error('Elegí una empresa del archivo.');
 const selected=name=>data[name].filter(x=>same(x.client_id,clientId));
 const s=empty(client.name),reference=(arr,id,label)=>{const r=arr.find(x=>x.id===id);if(!r)throw Error('Referencia incompleta o de otra empresa: '+label);return r};
 s.sectors=selected('sectors').map(x=>({id:key('sector',x.id),name:x.name,archived:!x.active}));
 const reception={id:key('sector','recepcion'),name:'Recepción importada',archived:false};s.sectors.push(reception);
 s.suppliers=selected('suppliers').map(x=>({id:key('supplier',x.id),name:x.name,taxId:x.tax_id||'',contact:x.contact||'',archived:!x.active}));
 const kinds={'Materia prima':'raw','Envase':'packaging','Subproducto':'subproduct','Producto intermedio':'subproduct','Producto terminado':'product'};
 s.items=selected('products').map(x=>{if(!kinds[x.category])throw Error('Revisar la categoría del artículo '+x.name+': '+x.category);if(!['kg','g','l','ml','u'].includes(x.unit))throw Error('Revisar la unidad de '+x.name+': '+x.unit);const supplierIds=selected('product_suppliers').filter(p=>same(p.product_id,x.id)).map(p=>reference(s.suppliers,key('supplier',p.supplier_id),'proveedor').id);return{id:key('item',x.id),name:x.name,kind:kinds[x.category],unit:x.unit,brand:x.default_brand||'',salePrice:0,supplierIds,supplierId:supplierIds[0]||'',archived:!x.active}});
 const recipes=selected('recipes').map(x=>{reference(s.items,key('item',x.output_product_id),'producto de receta');reference(s.sectors,key('sector',x.sector_id),'sector');return{id:key('recipe',x.id),itemId:key('item',x.output_product_id),sectorId:key('sector',x.sector_id),yield:n(x.output_qty,'Rendimiento'),version:1,sourceVersion:String(x.version),archived:!x.active,components:data.recipe_items.filter(i=>same(i.recipe_id,x.id)).map(i=>({itemId:reference(s.items,key('item',i.product_id),'ingrediente').id,qty:n(i.qty,'Ingrediente')}))}});
 s.recipes=recipes.filter(r=>!r.archived);if(new Set(s.recipes.map(r=>r.itemId)).size!==s.recipes.length)throw Error('Hay varias recetas activas para el mismo producto. Hay que elegir cuál utilizar antes de importar.');
 for(const r of s.recipes){if(!r.components.length)throw Error('Receta sin componentes');recipeCost(s,r.itemId);}
 for(const x of selected('receipts')){const item=reference(s.items,key('item',x.product_id),'artículo de ingreso');if(x.unit!==item.unit)throw Error('La unidad de un ingreso no coincide con el artículo.');const qty=n(x.qty,'Ingreso'),unitCost=n(x.unit_price,'Precio',true),date=day(x.received_at),id=key('receipt',x.id),lotId=key('receipt-lot',x.id);reference(s.suppliers,key('supplier',x.supplier_id),'proveedor de ingreso');s.purchases.push({id,itemId:item.id,date,qty,unitCost,supplierId:key('supplier',x.supplier_id),supplierLot:x.supplier_lot||'',note:x.notes||'',lotId});s.lots.push({id:lotId,code:x.internal_lot,itemId:item.id,qty,remaining:qty,unitCost,date,expiry:x.expires_at?day(x.expires_at):'',sectorId:reception.id,status:'LIBERADO',sourceId:id});}
 const pending=selected('batches'),done=new Set();
 function build(x,stack=new Set()){
  if(done.has(String(x.id)))return;
  if(stack.has(String(x.id)))throw Error('Ciclo entre elaboraciones de TRAZA5.');stack.add(String(x.id));
  const inputs=data.batch_inputs.filter(i=>same(i.batch_id,x.id)).map(i=>{if(!['batch','receipt'].includes(i.source_type))throw Error('Tipo de origen inválido.');if(i.source_type==='batch'){const source=pending.find(b=>same(b.id,i.source_id));if(!source)throw Error('Elaboración de origen inexistente o de otra empresa.');build(source,new Set(stack));}const lotId=key(i.source_type==='batch'?'batch-lot':'receipt-lot',i.source_id),lot=reference(s.lots,lotId,'lote consumido');if(lot.itemId!==key('item',i.product_id))throw Error('El ingrediente no coincide con el lote.');const qty=n(i.qty,'Consumo');if(qty>lot.remaining+1e-8)throw Error('TRAZA5 tiene consumos mayores al saldo del lote '+lot.code);lot.remaining=Math.max(0,lot.remaining-qty);return{lotId,itemId:lot.itemId,qty,unitCost:lot.unitCost}});
  if(!inputs.length)throw Error('Elaboración sin consumos: '+x.internal_lot);
  const recipe=reference(recipes,key('recipe',x.recipe_id),'receta histórica'),itemId=reference(s.items,key('item',x.product_id),'producto elaborado').id;
  if(recipe.itemId!==itemId)throw Error('Receta y producto elaborado no coinciden.');
  if(!['LIBERADO','BLOQUEADO','RECHAZADO'].includes(x.status))throw Error('Estado de lote inválido.');
  const qty=n(x.qty,'Elaboración'),date=day(x.produced_at),cost=inputs.reduce((a,i)=>a+i.qty*i.unitCost,0)/qty,id=key('batch',x.id),lotId=key('batch-lot',x.id);
  if(inputs.some(i=>reference(s.lots,i.lotId,'lote').date>date))throw Error('Consumo anterior al ingreso del lote.');
  s.productions.push({id,itemId,sectorId:reference(s.sectors,key('sector',x.sector_id),'sector de elaboración').id,date,recipe:structuredClone(recipe),batches:qty/recipe.yield,expectedQty:qty,qty,unitCost:cost,inputs,lotId,imported:true});
  s.lots.push({id:lotId,code:x.final_lot||x.internal_lot,internalCode:x.internal_lot,itemId,qty,remaining:qty,unitCost:cost,date,expiry:'',sectorId:key('sector',x.sector_id),status:x.status,sourceId:id});done.add(String(x.id));
 }
 pending.forEach(x=>build(x));s.counter=s.lots.length;s.lastStockDate=s.lots.map(x=>x.date).sort().at(-1)||'';
 for(const i of s.items){const lots=s.lots.filter(l=>l.itemId===i.id&&l.remaining>0),qty=lots.reduce((a,l)=>a+l.remaining,0);s.averages[i.id]=qty?lots.reduce((a,l)=>a+l.remaining*l.unitCost,0)/qty:0;}
 s.importInfo={source:'TRAZA5',clientId:String(clientId),at:new Date().toISOString(),notes:['Costos iniciales calculados desde los precios de los lotes de origen.','Ingresos históricos ubicados en Recepción importada; trasladar antes de producir.','TRAZA5 no registra vencimiento de elaboraciones: se conserva sin fecha.','Usuarios y contraseñas se configuran en Gestión Integral.'],audit:(data.audit_log||[]).filter(x=>same(x.client_id,clientId))};
 return s;
}
