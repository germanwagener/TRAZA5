import {randomBytes,createCipheriv,createDecipheriv,randomUUID} from 'node:crypto';
import {mkdirSync,writeFileSync,readFileSync,readdirSync,renameSync,existsSync} from 'node:fs';
import {join} from 'node:path';

export const backupDay=(date=new Date())=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/Argentina/Buenos_Aires',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
export function seal(data,key){
 const nonce=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,nonce);
 return Buffer.concat([Buffer.from('TRAZA01'),nonce,cipher.update(JSON.stringify(data)),cipher.final(),cipher.getAuthTag()]);
}
export function unseal(bytes,key){
 if(bytes.length<35||bytes.subarray(0,7).toString()!=='TRAZA01')throw Error('Formato de respaldo inválido.');
 const decipher=createDecipheriv('aes-256-gcm',key,bytes.subarray(7,19));decipher.setAuthTag(bytes.subarray(-16));
 return JSON.parse(Buffer.concat([decipher.update(bytes.subarray(19,-16)),decipher.final()]).toString());
}
export function createBackupStore(db,directory){
 mkdirSync(directory,{recursive:true});
 const keyPath=join(directory,'recovery.key');
 const configuredKey=process.env.BACKUP_RECOVERY_KEY?Buffer.from(process.env.BACKUP_RECOVERY_KEY,'base64'):null;
 if(configuredKey&&configuredKey.length!==32)throw Error('Clave de recuperación inválida.');
 if(!existsSync(keyPath))writeFileSync(keyPath,configuredKey||randomBytes(32),{flag:'wx',mode:0o600});
 if(configuredKey&&!configuredKey.equals(readFileSync(keyPath)))throw Error('La clave de recuperación no coincide con los respaldos existentes.');
 const key=readFileSync(keyPath);if(key.length!==32)throw Error('Clave de respaldo inválida.');
 const filename=name=>{if(!/^Traza_\d{4}-\d{2}-\d{2}_[a-z0-9-]+\.respaldo\.enc$/.test(name))throw Error('Respaldo inválido.');return join(directory,name)};
 function snapshot(){
  db.exec('BEGIN');try{const data={format:'traza-full-v1',createdAt:new Date().toISOString(),companies:db.prepare('SELECT * FROM companies').all(),users:db.prepare('SELECT * FROM users').all(),audit:db.prepare('SELECT * FROM audit').all()};db.exec('COMMIT');return data}catch(e){db.exec('ROLLBACK');throw e}
 }
 function create(reason='manual'){
  const data=snapshot(),name=`Traza_${backupDay()}_${reason}-${randomUUID()}.respaldo.enc`,target=filename(name);
  writeFileSync(target+'.tmp',seal(data,key),{flag:'wx',mode:0o600});renameSync(target+'.tmp',target);return{name,createdAt:data.createdAt};
 }
 function read(name){const data=unseal(readFileSync(filename(name)),key);
  if(data.format!=='traza-full-v1'||!Array.isArray(data.companies)||!Array.isArray(data.users)||!Array.isArray(data.audit))throw Error('Contenido de respaldo inválido.');
  for(const c of data.companies){const s=JSON.parse(c.state);if(!Array.isArray(s.items)||!Number.isSafeInteger(c.version))throw Error('Empresa inválida en el respaldo.');}
  return data;
 }
 function preview(name){const data=read(name);return{name,createdAt:data.createdAt,companies:data.companies.map(c=>c.name),users:data.users.filter(u=>u.role==='company').length}}
 function restore(name,adminId){
  const data=read(name),safety=create('antes-restaurar');
  db.exec('BEGIN IMMEDIATE');try{
   const versions=new Map(db.prepare('SELECT id,version FROM companies').all().map(c=>[c.id,c.version]));
   // Keep current administrators and their credentials so recovery cannot lock them out.
   db.exec("DELETE FROM sessions; DELETE FROM users WHERE role='company'; DELETE FROM companies; DELETE FROM audit; DELETE FROM attempts;");
   for(const c of data.companies)db.prepare('INSERT INTO companies VALUES(?,?,?,?)').run(c.id,c.name,c.state,Math.max(c.version,versions.get(c.id)||0)+1);
   for(const u of data.users.filter(u=>u.role==='company'))db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?,?)').run(u.id,u.username,u.password,u.role,u.company_id,u.blocked,u.must_change);
   for(const a of data.audit)db.prepare('INSERT INTO audit VALUES(?,?,?,?,?,?)').run(a.id,a.at,a.user_id,a.company_id,a.operation,a.detail);
   db.prepare('INSERT INTO audit VALUES(?,?,?,?,?,?)').run(randomUUID(),new Date().toISOString(),adminId,null,'backup_restored',JSON.stringify({name,safety:safety.name}));
   db.exec('COMMIT');return{safety:safety.name};
  }catch(e){db.exec('ROLLBACK');throw e}
 }
 return{create,preview,restore,bytes:name=>readFileSync(filename(name)),importBytes(name,bytes){
  const data=unseal(bytes,key);if(data.format!=='traza-full-v1'||!Array.isArray(data.companies)||!Array.isArray(data.users)||!Array.isArray(data.audit))throw Error('Respaldo inválido.');
  const target=filename(name);writeFileSync(target+'.tmp',bytes,{mode:0o600});renameSync(target+'.tmp',target);
 },list:()=>readdirSync(directory).filter(n=>/^Traza_.*\.respaldo\.enc$/.test(n)).sort().reverse().map(name=>({name,date:name.slice(6,16)}))};
}
