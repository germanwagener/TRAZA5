import readline from 'node:readline';
import {Writable} from 'node:stream';
import {spawnSync,spawn,execFile} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
import {appendFileSync} from 'node:fs';
process.chdir(dirname(fileURLToPath(import.meta.url)));
const logPath=join(process.cwd(),'ERROR-ARRANQUE.txt');
function fail(message){
 const text=String(message||'No se pudo iniciar el programa.');
 console.error('\nNO SE PUDO ABRIR EL PROGRAMA\n'+text+'\n');
 try{appendFileSync(logPath,new Date().toISOString()+'\n'+text+'\n\n');console.error('El detalle quedó en ERROR-ARRANQUE.txt. Podés enviarme ese archivo.')}catch{}
 process.exitCode=1;
}
async function main(){
 if(Number(process.versions.node.split('.')[0])<24)throw Error('El motor incluido no es compatible. Extraé nuevamente el ZIP completo.');
 let muted=false;
 const out=new Writable({write(chunk,encoding,done){if(!muted)process.stdout.write(chunk,encoding);done()}});
 const rl=readline.createInterface({input:process.stdin,output:out,terminal:!!process.stdin.isTTY});
 const ask=(prompt,secret=false)=>new Promise(resolve=>{process.stdout.write(prompt);muted=secret;rl.question('',answer=>{muted=false;if(secret)process.stdout.write('\n');resolve(answer)})});
 const exists=spawnSync(process.execPath,['server.mjs','--has-admin'],{encoding:'utf8',windowsHide:true});
 if(exists.error||exists.status!==0){rl.close();throw Error(exists.error?.message||exists.stderr||'No se pudo abrir la base de datos.');}
 try{
  if(exists.stdout.trim()==='no'){
   console.log('Primera apertura: creá tu administrador de accesos.');
   let username;
   while(true){
    username=(await ask('Usuario administrador: ')).trim().toLowerCase();
    if(/^[a-z0-9_.-]{3,60}$/.test(username))break;
    console.log('Usá de 3 a 60 letras sin acentos, números, puntos o guiones. Probá otra vez.');
   }
   while(true){
    const pass=await ask('Contraseña (4 a 128 caracteres; no se muestra al escribir): ',true);
    if(pass.length<4||pass.length>128){console.log('La contraseña debe tener entre 4 y 128 caracteres. Escribí otra; el programa sigue abierto.');continue;}
    const confirmation=await ask('Repetí la contraseña: ',true);
    if(pass!==confirmation){console.log('Las contraseñas no coinciden. Volvé a escribirlas.');continue;}
    const setup=spawnSync(process.execPath,['server.mjs','--create-admin'],{env:{...process.env,ADMIN_USER:username,ADMIN_PASSWORD:pass},encoding:'utf8',windowsHide:true});
    if(setup.error||setup.status!==0)throw Error(setup.error?.message||setup.stderr||'No se pudo crear el administrador.');
    console.log('Administrador creado correctamente. Abriendo el programa…');break;
   }
  }
 }finally{rl.close();}
 console.log('Mantené esta ventana abierta durante el uso.');
 const address=process.env.PUBLIC_ORIGIN||`http://localhost:${process.env.PORT||3000}`;
 const child=spawn(process.execPath,['server.mjs'],{stdio:['ignore','pipe','pipe'],windowsHide:true});
 let output='',errors='',opened=false;
 child.stderr.on('data',chunk=>{errors+=chunk;process.stderr.write(chunk)});
 child.stdout.on('data',chunk=>{
  process.stdout.write(chunk);output+=chunk;
  if(!opened&&output.includes('disponible')){
   opened=true;console.log('Si el navegador no se abre, ingresá a: '+address);
   if(process.platform==='win32')execFile('rundll32.exe',['url.dll,FileProtocolHandler',address],err=>{if(err)console.log('Abrí tu navegador e ingresá a: '+address)});
  }
 });
 child.on('error',err=>fail(err.message));
 child.on('exit',(code,signal)=>{
  if(code!==0&&!signal)fail(errors.includes('EADDRINUSE')?'Ya hay un programa usando ese puerto. Si Gestión Integral ya está abierto, ingresá a '+address+'. Si no, cerrá la otra ventana de Gestión Integral e intentá nuevamente.':errors||'El servidor se cerró antes de abrirse.');
 });
 process.on('SIGINT',()=>child.kill());
}
main().catch(fail);
