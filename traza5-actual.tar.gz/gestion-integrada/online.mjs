import {spawnSync} from 'node:child_process';
import {existsSync} from 'node:fs';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
const mount=process.env.RAILWAY_VOLUME_MOUNT_PATH;
if(process.env.RAILWAY_ENVIRONMENT_ID&&!mount)throw Error('Conectá un volumen persistente antes de iniciar.');
if(mount&&!existsSync(mount))throw Error('El volumen persistente no está disponible.');
process.env.DB_PATH ||= join(mount||'data','gestion.sqlite');
process.env.HOST='0.0.0.0';
process.env.PUBLIC_ORIGIN ||= process.env.RAILWAY_PUBLIC_DOMAIN ? `https://${process.env.RAILWAY_PUBLIC_DOMAIN}` : '';
if(!process.env.PUBLIC_ORIGIN.startsWith('https://'))throw Error('Configurá PUBLIC_ORIGIN con la dirección HTTPS del programa.');
const server=new URL('./server.mjs',import.meta.url);
const probe=spawnSync(process.execPath,[server.pathname.replace(/^\/([A-Za-z]:)/,'$1'),'--has-admin'],{env:process.env,encoding:'utf8'});
if(probe.status!==0)throw Error('No se pudo comprobar la base de datos.');
if(probe.stdout.trim()==='no'){
 const initial=process.env.ADMIN_PASSWORD||process.env.ADMIN_INITIAL_PASSWORD;
 if(!initial||initial.length<12)throw Error('Configurá una contraseña inicial de al menos 12 caracteres.');
 const created=spawnSync(process.execPath,[server.pathname.replace(/^\/([A-Za-z]:)/,'$1'),'--create-admin'],{env:{...process.env,ADMIN_PASSWORD:initial},encoding:'utf8'});
 if(created.status!==0)throw Error('No se pudo crear el administrador.');
}
delete process.env.ADMIN_PASSWORD;
delete process.env.ADMIN_INITIAL_PASSWORD;
await import('./server.mjs');
