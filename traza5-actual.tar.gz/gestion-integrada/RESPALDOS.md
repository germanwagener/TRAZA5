# Respaldos completos y Google Drive

El administrador dispone de Respaldos y restauración. Las copias incluyen empresas, usuarios, historial y PDF. Se cifran con AES-256-GCM en el volumen persistente. Restaurar reemplaza todas las empresas y usuarios de empresa, conserva los administradores actuales, guarda una copia previa y cierra las sesiones.

## Activación

1. Habilitar Google Drive API en el proyecto de Google. Configurar un cliente OAuth web con retorno a PUBLIC_ORIGIN/api/admin/drive/callback.
2. Configurar GOOGLE_CLIENT_ID y GOOGLE_CLIENT_SECRET como variables privadas de Railway. No incluirlas en GitHub.
3. En la cuenta admin, guardar la clave de recuperación fuera de Railway. El archivo descargado contiene una clave privada, no una copia de los datos.
4. Conectar Google Drive con consultora.alimentos.ros@gmail.com. Se solicita únicamente drive.file. Traza crea su propia carpeta privada Respaldos Traza, porque el permiso limitado no permite usar automáticamente carpetas creadas por otras aplicaciones.
5. La aplicación OAuth debe pasar a producción para que el permiso de uso continuo no expire a los siete días del modo de prueba. No publicar enlaces de autorización para terceros.
6. Verificar un envío real y recuperar una copia en una instalación aislada antes de declarar activa la protección.

Railway ejecuta una comprobación cada 15 minutos y al iniciar. Se crea una copia por fecha de Argentina, y se reintentan las pendientes. La confirmación de Google incluye comprobación MD5 del archivo cifrado; la restauración verifica además su autenticidad AES-GCM. No se eliminan archivos automáticamente. Sin conexión configurada no hay envío automático y el panel lo indica.

## Recuperación si se pierde el volumen

Crear una instalación nueva con administrador. Antes del primer inicio, configurar BACKUP_RECOVERY_KEY con el campo key del archivo privado de recuperación, además de GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET y GOOGLE_DRIVE_FOLDER con el ID de la carpeta original. Conectar la misma cuenta usando el mismo cliente OAuth. Las copias remotas aparecen en el panel y se pueden recuperar por fecha. No cambiar la clave de un volumen con copias existentes: el servidor rechaza claves que no coinciden.

Mantener una sola réplica. Las claves y permisos de Google no se incluyen en las copias de los datos operativos. La clave de recuperación debe conservarse por separado. El repositorio público nunca debe contener secretos, archivos de respaldo o datos privados.
